import numpy as np
import pandas as pd
import joblib
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score, classification_report, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')

def test_model():
    """Test the compatible sleep disorder model"""
    print("=== Testing Compatible Sleep Disorder Model ===")
    
    # Load the model
    try:
        print("Loading model from compatible_sleep_model.pkl...")
        model_data = joblib.load('compatible_sleep_model.pkl')
        
        pipeline = model_data['pipeline']
        numerical_features = model_data['numerical_features']
        categorical_features = model_data['categorical_features']
        
        print("Model loaded successfully!")
        print(f"Model type: {model_data.get('model_type', 'Unknown')}")
        print(f"Version: {model_data.get('version', 'Unknown')}")
        print(f"Numerical features: {len(numerical_features)}")
        print(f"Categorical features: {len(categorical_features)}")
        
    except Exception as e:
        print(f"ERROR loading model: {e}")
        return
    
    # Generate test data
    print("\nGenerating test data...")
    np.random.seed(123)
    n_test_samples = 1000
    
    # Generate realistic test features
    age = np.random.normal(45, 15, n_test_samples).clip(18, 80)
    gender = np.random.choice(['Male', 'Female'], n_test_samples)
    bmi_categories = np.random.choice(['Underweight', 'Normal', 'Overweight', 'Obese'], 
                                     n_test_samples, p=[0.05, 0.4, 0.35, 0.2])
    sleep_duration = np.random.normal(7.5, 1.5, n_test_samples).clip(4, 12)
    physical_activity = np.random.exponential(50, n_test_samples).clip(0, 200)
    heart_rate = np.random.normal(75, 15, n_test_samples).clip(50, 120)
    daily_steps = np.random.normal(8000, 3000, n_test_samples).clip(1000, 20000)
    stress_level = np.random.uniform(1, 10, n_test_samples)
    
    # Time-based features
    weekday_bedtime = np.random.normal(22.5, 1.5, n_test_samples).clip(18, 2)
    weekday_bedtime_hour = np.floor(weekday_bedtime).astype(int)
    weekday_bedtime_minute = ((weekday_bedtime % 1) * 60).astype(int)
    weekday_wakeup = weekday_bedtime + (sleep_duration + np.random.normal(0, 0.5, n_test_samples))
    weekday_wakeup_hour = np.floor(weekday_wakeup % 24).astype(int)
    weekday_wakeup_minute = ((weekday_wakeup % 1) * 60).astype(int)
    weekend_bedtime = weekday_bedtime + np.random.normal(1.5, 1, n_test_samples)
    weekend_bedtime_hour = np.floor(weekend_bedtime % 24).astype(int)
    weekend_bedtime_minute = ((weekend_bedtime % 1) * 60).astype(int)
    weekend_wakeup = weekend_bedtime + (sleep_duration + np.random.normal(1, 0.7, n_test_samples))
    weekend_wakeup_hour = np.floor(weekend_wakeup % 24).astype(int)
    weekend_wakeup_minute = ((weekend_wakeup % 1) * 60).astype(int)
    
    device_usage_prob = 0.3 + (0.6 * (1 - (age / 80)))
    use_electronic_devices = np.random.binomial(1, device_usage_prob, n_test_samples).astype(bool)
    
    # Create test dataframe
    test_df = pd.DataFrame({
        'Age': age,
        'Gender': gender,
        'BMI_Category': bmi_categories,
        'Sleep_Duration': sleep_duration,
        'Physical_Activity': physical_activity,
        'Heart_Rate': heart_rate,
        'Daily_Steps': daily_steps,
        'Stress_Level': stress_level,
        'Sleep_Quality': np.random.uniform(1, 10, n_test_samples),
        'Bedtime_Hour': weekday_bedtime_hour,
        'Bedtime_Minute': weekday_bedtime_minute,
        'Wakeup_Hour': weekday_wakeup_hour,
        'Wakeup_Minute': weekday_wakeup_minute,
        'Weekend_Bedtime_Hour': weekend_bedtime_hour,
        'Weekend_Bedtime_Minute': weekend_bedtime_minute,
        'Weekend_Wakeup_Hour': weekend_wakeup_hour,
        'Weekend_Wakeup_Minute': weekend_wakeup_minute,
        'Awakenings': np.random.poisson(1.2, n_test_samples),
        'Electronic_Devices_Before_Bed': use_electronic_devices,
        'Room_Temperature': np.clip(np.random.normal(21, 2, n_test_samples), 16, 28),
        'Noise_Level': np.random.choice(['Low', 'Medium', 'High'], n_test_samples, p=[0.6, 0.3, 0.1]),
        'Caffeine_Intake': np.random.poisson(2, n_test_samples),
        'Alcohol_Consumption': np.random.choice(['None', 'Low', 'Moderate', 'High'], n_test_samples, p=[0.5, 0.3, 0.15, 0.05]),
        'Exercise_Frequency': np.random.choice(['None', '1-2', '3-4', '5+'], n_test_samples, p=[0.2, 0.4, 0.3, 0.1])
    })
    
    # Preprocess test data (same as training)
    print("Preprocessing test data...")
    weekday_bedtime = test_df['Bedtime_Hour'] + test_df['Bedtime_Minute']/60
    weekend_bedtime = test_df['Weekend_Bedtime_Hour'] + test_df['Weekend_Bedtime_Minute']/60
    
    test_df['Sleep_Efficiency'] = test_df['Sleep_Duration'] / ((test_df['Wakeup_Hour'] + test_df['Wakeup_Minute']/60) - weekday_bedtime)
    test_df['Social_Jetlag'] = abs(weekend_bedtime - weekday_bedtime)
    test_df['Sleep_Regularity'] = 1 / (1 + test_df['Social_Jetlag'])
    test_df['Late_Night_Device_Use'] = test_df['Electronic_Devices_Before_Bed'] & (test_df['Bedtime_Hour'] >= 23)
    test_df['Sleep_Time_Variability'] = test_df.apply(lambda row: abs((row['Weekend_Bedtime_Hour'] - row['Bedtime_Hour']) + abs((row['Weekend_Wakeup_Hour'] - row['Wakeup_Hour']))/60), axis=1)
    test_df['Sleep_Deficit'] = np.where(test_df['Sleep_Duration'] < 7, 7 - test_df['Sleep_Duration'], 0)
    test_df['Stress_Sleep_Interaction'] = test_df['Stress_Level'] * (8 - test_df['Sleep_Duration'])
    test_df['Circadian_Disruption'] = abs(weekend_bedtime - weekday_bedtime)
    test_df['Stress_Sleep_Ratio'] = test_df['Stress_Level'] / (test_df['Sleep_Duration'] + 1e-6)
    
    # Encode categorical variables
    test_df['BMI_Numeric'] = test_df['BMI_Category'].map({'Underweight': 0, 'Normal': 1, 'Overweight': 2, 'Obese': 3})
    test_df['Alcohol_Numeric'] = test_df['Alcohol_Consumption'].map({'None': 0, 'Low': 1, 'Moderate': 2, 'High': 3})
    test_df['Exercise_Numeric'] = test_df['Exercise_Frequency'].map({'None': 0, '1-2': 1, '3-4': 2, '5+': 3})
    
    # Create true labels for evaluation
    sleep_disorder_prob = (
        0.03 * (age - 40) + 0.1 * (heart_rate - 70) - 0.4 * (sleep_duration - 7) +
        0.2 * (stress_level - 5) + 0.3 * (bmi_categories == 'Obese') +
        0.15 * (bmi_categories == 'Overweight') + 0.25 * use_electronic_devices -
        0.0001 * daily_steps + 0.5 * (weekday_bedtime > 23.5)
    )
    sleep_disorder_prob = 1 / (1 + np.exp(-sleep_disorder_prob))
    true_labels = np.random.binomial(1, sleep_disorder_prob)
    
    # Make predictions
    print("Making predictions...")
    try:
        predictions = pipeline.predict(test_df)
        probabilities = pipeline.predict_proba(test_df)[:, 1]
        
        print(f"Predictions shape: {predictions.shape}")
        print(f"Probabilities shape: {probabilities.shape}")
        print(f"True labels shape: {true_labels.shape}")
        
        # Evaluate model
        print("\n=== Model Evaluation ===")
        print(f"Accuracy: {accuracy_score(true_labels, predictions):.4f}")
        print(f"F1 Score: {f1_score(true_labels, predictions):.4f}")
        print(f"ROC AUC: {roc_auc_score(true_labels, probabilities):.4f}")
        
        print("\nClassification Report:")
        print(classification_report(true_labels, predictions))
        
        # Confusion Matrix
        cm = confusion_matrix(true_labels, predictions)
        plt.figure(figsize=(8, 6))
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                   xticklabels=['No Disorder', 'Sleep Disorder'],
                   yticklabels=['No Disorder', 'Sleep Disorder'])
        plt.title('Confusion Matrix')
        plt.ylabel('True Label')
        plt.xlabel('Predicted Label')
        plt.tight_layout()
        plt.savefig('compatible_confusion_matrix.png', dpi=300, bbox_inches='tight')
        plt.close()
        print("Confusion matrix saved as compatible_confusion_matrix.png")
        
        # Prediction distribution
        plt.figure(figsize=(10, 6))
        plt.hist(probabilities[true_labels == 0], bins=30, alpha=0.7, label='No Disorder', density=True)
        plt.hist(probabilities[true_labels == 1], bins=30, alpha=0.7, label='Sleep Disorder', density=True)
        plt.xlabel('Predicted Probability')
        plt.ylabel('Density')
        plt.title('Prediction Probability Distribution')
        plt.legend()
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig('compatible_prediction_distribution.png', dpi=300, bbox_inches='tight')
        plt.close()
        print("Prediction distribution saved as compatible_prediction_distribution.png")
        
        # Sample predictions
        print("\n=== Sample Predictions ===")
        sample_indices = np.random.choice(len(test_df), 10, replace=False)
        for i, idx in enumerate(sample_indices):
            print(f"Sample {i+1}:")
            print(f"  Age: {test_df.iloc[idx]['Age']:.1f}, Sleep Duration: {test_df.iloc[idx]['Sleep_Duration']:.1f}")
            print(f"  Stress Level: {test_df.iloc[idx]['Stress_Level']:.1f}, Heart Rate: {test_df.iloc[idx]['Heart_Rate']:.0f}")
            print(f"  True Label: {true_labels[idx]}, Predicted: {predictions[idx]}, Probability: {probabilities[idx]:.3f}")
            print()
        
        print("Model testing completed successfully!")
        
    except Exception as e:
        print(f"ERROR during prediction: {e}")
        import traceback
        traceback.print_exc()

if __name__ == '__main__':
    test_model() 