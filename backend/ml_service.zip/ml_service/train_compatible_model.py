import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, StratifiedKFold, RandomizedSearchCV
from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score, classification_report
import joblib
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')

# Model path
MODEL_PATH = 'compatible_sleep_model.pkl'

def get_dataset():
    """Generate synthetic sleep disorder dataset"""
    np.random.seed(42)
    n_samples = 10000
    
    # Generate realistic features
    age = np.random.normal(45, 15, n_samples).clip(18, 80)
    gender = np.random.choice(['Male', 'Female'], n_samples)
    bmi_categories = np.random.choice(['Underweight', 'Normal', 'Overweight', 'Obese'], 
                                     n_samples, p=[0.05, 0.4, 0.35, 0.2])
    sleep_duration = np.random.normal(7.5, 1.5, n_samples).clip(4, 12)
    physical_activity = np.random.exponential(50, n_samples).clip(0, 200)
    heart_rate = np.random.normal(75, 15, n_samples).clip(50, 120)
    daily_steps = np.random.normal(8000, 3000, n_samples).clip(1000, 20000)
    stress_level = np.random.uniform(1, 10, n_samples)
    
    # Time-based features
    weekday_bedtime = np.random.normal(22.5, 1.5, n_samples).clip(18, 2)
    weekday_bedtime_hour = np.floor(weekday_bedtime).astype(int)
    weekday_bedtime_minute = ((weekday_bedtime % 1) * 60).astype(int)
    weekday_wakeup = weekday_bedtime + (sleep_duration + np.random.normal(0, 0.5, n_samples))
    weekday_wakeup_hour = np.floor(weekday_wakeup % 24).astype(int)
    weekday_wakeup_minute = ((weekday_wakeup % 1) * 60).astype(int)
    weekend_bedtime = weekday_bedtime + np.random.normal(1.5, 1, n_samples)
    weekend_bedtime_hour = np.floor(weekend_bedtime % 24).astype(int)
    weekend_bedtime_minute = ((weekend_bedtime % 1) * 60).astype(int)
    weekend_wakeup = weekend_bedtime + (sleep_duration + np.random.normal(1, 0.7, n_samples))
    weekend_wakeup_hour = np.floor(weekend_wakeup % 24).astype(int)
    weekend_wakeup_minute = ((weekend_wakeup % 1) * 60).astype(int)
    
    device_usage_prob = 0.3 + (0.6 * (1 - (age / 80)))
    use_electronic_devices = np.random.binomial(1, device_usage_prob, n_samples).astype(bool)
    
    # Sleep disorder probability
    sleep_disorder_prob = (
        0.03 * (age - 40) + 0.1 * (heart_rate - 70) - 0.4 * (sleep_duration - 7) +
        0.2 * (stress_level - 5) + 0.3 * (bmi_categories == 'Obese') +
        0.15 * (bmi_categories == 'Overweight') + 0.25 * use_electronic_devices -
        0.0001 * daily_steps + 0.5 * (weekday_bedtime > 23.5)
    )
    sleep_disorder_prob = 1 / (1 + np.exp(-sleep_disorder_prob))
    sleep_disorder = np.random.binomial(1, sleep_disorder_prob)
    
    sleep_disorder_type = np.where(
        sleep_disorder == 1,
        np.random.choice(['Insomnia', 'Sleep Apnea', 'Restless Legs Syndrome'], n_samples, p=[0.5, 0.3, 0.2]),
        'None'
    )
    
    # Sleep quality
    base_quality = (
        7.0 - 0.4 * (stress_level / 10) - 0.3 * (sleep_disorder == 1) -
        0.2 * (weekday_bedtime > 23.5) + 0.1 * (physical_activity / 100) +
        np.random.normal(0, 0.5, n_samples)
    )
    sleep_quality = np.clip(base_quality, 1, 10)
    
    data = pd.DataFrame({
        'Age': age,
        'Gender': gender,
        'BMI_Category': bmi_categories,
        'Sleep_Duration': sleep_duration,
        'Physical_Activity': physical_activity,
        'Heart_Rate': heart_rate,
        'Daily_Steps': daily_steps,
        'Stress_Level': stress_level,
        'Sleep_Quality': sleep_quality,
        'Sleep_Disorder': sleep_disorder_type,
        'Bedtime_Hour': weekday_bedtime_hour,
        'Bedtime_Minute': weekday_bedtime_minute,
        'Wakeup_Hour': weekday_wakeup_hour,
        'Wakeup_Minute': weekday_wakeup_minute,
        'Weekend_Bedtime_Hour': weekend_bedtime_hour,
        'Weekend_Bedtime_Minute': weekend_bedtime_minute,
        'Weekend_Wakeup_Hour': weekend_wakeup_hour,
        'Weekend_Wakeup_Minute': weekend_wakeup_minute,
        'Awakenings': np.random.poisson(1.2, n_samples),
        'Electronic_Devices_Before_Bed': use_electronic_devices,
        'Room_Temperature': np.clip(np.random.normal(21, 2, n_samples), 16, 28),
        'Noise_Level': np.random.choice(['Low', 'Medium', 'High'], n_samples, p=[0.6, 0.3, 0.1]),
        'Caffeine_Intake': np.random.poisson(2, n_samples),
        'Alcohol_Consumption': np.random.choice(['None', 'Low', 'Moderate', 'High'], n_samples, p=[0.5, 0.3, 0.15, 0.05]),
        'Exercise_Frequency': np.random.choice(['None', '1-2', '3-4', '5+'], n_samples, p=[0.2, 0.4, 0.3, 0.1])
    })
    
    return data

def preprocess_data(df):
    """Preprocess the dataset with feature engineering"""
    # Create target variable
    df['Has_Sleep_Disorder'] = df['Sleep_Disorder'].apply(lambda x: 0 if x == 'None' else 1)
    
    # Feature engineering
    weekday_bedtime = df['Bedtime_Hour'] + df['Bedtime_Minute']/60
    weekend_bedtime = df['Weekend_Bedtime_Hour'] + df['Weekend_Bedtime_Minute']/60
    
    df['Sleep_Efficiency'] = df['Sleep_Duration'] / ((df['Wakeup_Hour'] + df['Wakeup_Minute']/60) - weekday_bedtime)
    df['Social_Jetlag'] = abs(weekend_bedtime - weekday_bedtime)
    df['Sleep_Regularity'] = 1 / (1 + df['Social_Jetlag'])
    df['Late_Night_Device_Use'] = df['Electronic_Devices_Before_Bed'] & (df['Bedtime_Hour'] >= 23)
    df['Sleep_Time_Variability'] = df.apply(lambda row: abs((row['Weekend_Bedtime_Hour'] - row['Bedtime_Hour']) + abs((row['Weekend_Wakeup_Hour'] - row['Wakeup_Hour']))/60), axis=1)
    df['Sleep_Deficit'] = np.where(df['Sleep_Duration'] < 7, 7 - df['Sleep_Duration'], 0)
    df['Stress_Sleep_Interaction'] = df['Stress_Level'] * (8 - df['Sleep_Duration'])
    df['Circadian_Disruption'] = abs(weekend_bedtime - weekday_bedtime)
    df['Stress_Sleep_Ratio'] = df['Stress_Level'] / (df['Sleep_Duration'] + 1e-6)
    
    # Encode categorical variables
    df['BMI_Numeric'] = df['BMI_Category'].map({'Underweight': 0, 'Normal': 1, 'Overweight': 2, 'Obese': 3})
    df['Alcohol_Numeric'] = df['Alcohol_Consumption'].map({'None': 0, 'Low': 1, 'Moderate': 2, 'High': 3})
    df['Exercise_Numeric'] = df['Exercise_Frequency'].map({'None': 0, '1-2': 1, '3-4': 2, '5+': 3})

    # Define features
    numerical_features = [
        'Age', 'Sleep_Duration', 'Physical_Activity', 'Heart_Rate',
        'Daily_Steps', 'Stress_Level', 'Sleep_Quality', 'Awakenings',
        'Room_Temperature', 'Caffeine_Intake', 'Sleep_Efficiency',
        'Social_Jetlag', 'Sleep_Regularity', 'Sleep_Time_Variability',
        'Sleep_Deficit', 'Stress_Sleep_Interaction',
        'BMI_Numeric', 'Alcohol_Numeric', 'Exercise_Numeric',
        'Circadian_Disruption', 'Stress_Sleep_Ratio'
    ]

    categorical_features = [
        'Gender', 'BMI_Category', 'Electronic_Devices_Before_Bed',
        'Late_Night_Device_Use', 'Noise_Level', 'Alcohol_Consumption',
        'Exercise_Frequency'
    ]

    # Create preprocessor
    preprocessor = ColumnTransformer(
        transformers=[
            ('num', StandardScaler(), numerical_features),
            ('cat', OneHotEncoder(handle_unknown='ignore', sparse_output=False), categorical_features)
        ]
    )

    X = df[numerical_features + categorical_features]
    y = df['Has_Sleep_Disorder']
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
    
    return X_train, X_test, y_train, y_test, preprocessor, numerical_features, categorical_features

def main():
    print("=== Compatible Sleep Disorder Model Training ===")
    
    # Generate dataset
    print("Generating dataset...")
    df = get_dataset()
    
    # Preprocess data
    print("Preprocessing data...")
    X_train, X_test, y_train, y_test, preprocessor, num_feats, cat_feats = preprocess_data(df)
    
    print(f"Training set size: {X_train.shape[0]}")
    print(f"Test set size: {X_test.shape[0]}")
    print(f"Positive cases in training: {y_train.sum()} ({y_train.mean():.2%})")
    
    # Create a simple but effective model
    print("Training Random Forest model...")
    rf_model = RandomForestClassifier(
        n_estimators=200,
        max_depth=10,
        min_samples_split=5,
        min_samples_leaf=2,
        random_state=42,
        class_weight='balanced',
        n_jobs=-1
    )
    
    # Create pipeline
    pipeline = Pipeline([
        ('preprocessor', preprocessor),
        ('classifier', rf_model)
    ])
    
    # Train the model
    pipeline.fit(X_train, y_train)
    
    # Evaluate on test set
    print("Evaluating model...")
    y_pred = pipeline.predict(X_test)
    y_proba = pipeline.predict_proba(X_test)[:, 1]
    
    print("\nTest set evaluation:")
    print("Accuracy:", accuracy_score(y_test, y_pred))
    print("F1 Score:", f1_score(y_test, y_pred))
    print("ROC AUC:", roc_auc_score(y_test, y_proba))
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred))
    
    # Save model with metadata
    print("Saving model...")
    model_data = {
        'pipeline': pipeline,
        'numerical_features': num_feats,
        'categorical_features': cat_feats,
        'feature_names': num_feats + cat_feats,
        'model_type': 'RandomForest',
        'version': '1.0'
    }
    
    # Use joblib with compression for better compatibility
    joblib.dump(model_data, MODEL_PATH, compress=3)
    print(f"Model saved as {MODEL_PATH}")
    
    # Feature importance
    try:
        feature_names = []
        feature_names.extend(preprocessor.named_transformers_['num'].get_feature_names_out())
        feature_names.extend(preprocessor.named_transformers_['cat'].get_feature_names_out())
        
        importances = rf_model.feature_importances_
        indices = np.argsort(importances)[::-1]
        
        plt.figure(figsize=(12, 8))
        plt.title("Feature Importance (Random Forest)")
        plt.bar(range(len(indices[:20])), importances[indices[:20]])
        plt.xticks(range(len(indices[:20])), [feature_names[i] for i in indices[:20]], rotation=45, ha='right')
        plt.tight_layout()
        plt.savefig("compatible_feature_importance.png", bbox_inches='tight', dpi=300)
        plt.close()
        print("Feature importance plot saved as compatible_feature_importance.png")
    except Exception as e:
        print("Feature importance plot failed:", e)
    
    print("\nTraining completed successfully!")

if __name__ == '__main__':
    main() 