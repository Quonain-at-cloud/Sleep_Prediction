import pandas as pd
import numpy as np
import joblib
import matplotlib.pyplot as plt
import seaborn as sns
import os
from sklearn.ensemble import RandomForestClassifier, StackingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split, GridSearchCV, StratifiedKFold
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.metrics import (classification_report, accuracy_score, 
                            confusion_matrix, roc_auc_score, 
                            precision_recall_curve, f1_score)
from sklearn.calibration import calibration_curve, CalibratedClassifierCV
from imblearn.over_sampling import SMOTE
from imblearn.under_sampling import RandomUnderSampler
from imblearn.pipeline import Pipeline as ImbPipeline
from xgboost import XGBClassifier
from lightgbm import LGBMClassifier
from sklearn.feature_selection import SelectFromModel

MODEL_PATH = os.path.join(os.path.dirname(__file__), 'improved_sleep_model.pkl')
FEATURE_IMPORTANCE_PATH = os.path.join(os.path.dirname(__file__), 'feature_importance.png')

def get_dataset():
    np.random.seed(42)
    n_samples = 3000
    age = np.random.normal(45, 15, n_samples).astype(int)
    age = np.clip(age, 18, 80)
    gender = np.random.choice(['Male', 'Female'], n_samples, p=[0.48, 0.52])
    bmi_categories = np.random.choice(['Normal', 'Overweight', 'Obese', 'Underweight'], n_samples, p=[0.45, 0.35, 0.15, 0.05])
    stress_level = np.random.randint(1, 11, n_samples)
    physical_activity = np.clip(np.random.normal(45, 20, n_samples) - (age/4), 0, 120)
    heart_rate = np.clip(np.random.normal(72, 8, n_samples) + (stress_level * 0.8), 55, 100)
    daily_steps = np.clip(np.random.normal(7500, 2500, n_samples) + (physical_activity * 50), 1000, 20000)
    base_sleep = 7.5 - (age * 0.01) - (stress_level * 0.1)
    sleep_duration = np.clip(np.random.normal(base_sleep, 1.2, n_samples), 3, 11)
    weekday_bedtime = np.random.normal(22.5, 1.5, n_samples)
    weekday_bedtime_hour = np.floor(weekday_bedtime).astype(int)
    weekday_bedtime_minute = ((weekday_bedtime % 1) * 60).astype(int)
    weekday_wakeup = weekday_bedtime + (sleep_duration + np.random.normal(0, 0.5, n_samples))
    weekday_wakeup_hour = np.floor(weekday_wakeup % 24).astype(int)
    weekday_wakeup_minute = ((weekday_wakeup % 1) * 60).astype(int)
    weekend_bedtime = weekday_bedtime + np.random.normal(1.5, 1, n_samples)
    weekend_bedtime_hour = np.floor(weekend_bedtime % 24).astype(int)
    weekend_bedtime_minute = ((weekend_bedtime % 1) * 60).astype(int)
    weekend_wakeup = weekend_bedtime + (sleep_duration + np.random.normal(1, 0.7, n_samples))
    weekend_wakeup_hour = np.floor(weekend_wakeup % 24).astype(int)
    weekend_wakeup_minute = ((weekend_wakeup % 1) * 60).astype(int)
    device_usage_prob = 0.3 + (0.6 * (1 - (age / 80)))
    use_electronic_devices = np.random.binomial(1, device_usage_prob, n_samples).astype(bool)
    sleep_disorder_prob = (
        0.03 * (age - 40) + 0.1 * (heart_rate - 70) -0.4 * (sleep_duration - 7) +
        0.2 * (stress_level - 5) + 0.3 * (bmi_categories == 'Obese') +
        0.15 * (bmi_categories == 'Overweight') + 0.25 * use_electronic_devices -
        0.0001 * daily_steps + 0.5 * (weekday_bedtime > 23.5)
    )
    sleep_disorder_prob = 1 / (1 + np.exp(-sleep_disorder_prob))
    sleep_disorder = np.random.binomial(1, sleep_disorder_prob)
    sleep_disorder_type = np.where(
        sleep_disorder == 1,
        np.random.choice(['Insomnia', 'Sleep Apnea', 'Restless Legs Syndrome'], n_samples, p=[0.5, 0.3, 0.2]),
        'None'
    )
    base_quality = (
        7.0 - 0.4 * (stress_level / 10) - 0.3 * (sleep_disorder == 1) -
        0.2 * (weekday_bedtime > 23.5) + 0.1 * (physical_activity / 100) +
        np.random.normal(0, 0.5, n_samples)
    )
    sleep_quality = np.clip(base_quality, 1, 10)
    data = pd.DataFrame({
        'Age': age,
        'Gender': gender,
        'BMI_Category': bmi_categories,
        'Sleep_Duration': sleep_duration,
        'Physical_Activity': physical_activity,
        'Heart_Rate': heart_rate,
        'Daily_Steps': daily_steps,
        'Stress_Level': stress_level,
        'Sleep_Quality': sleep_quality,
        'Sleep_Disorder': sleep_disorder_type,
        'Bedtime_Hour': weekday_bedtime_hour,
        'Bedtime_Minute': weekday_bedtime_minute,
        'Wakeup_Hour': weekday_wakeup_hour,
        'Wakeup_Minute': weekday_wakeup_minute,
        'Weekend_Bedtime_Hour': weekend_bedtime_hour,
        'Weekend_Bedtime_Minute': weekend_bedtime_minute,
        'Weekend_Wakeup_Hour': weekend_wakeup_hour,
        'Weekend_Wakeup_Minute': weekend_wakeup_minute,
        'Awakenings': np.random.poisson(1.2, n_samples),
        'Electronic_Devices_Before_Bed': use_electronic_devices,
        'Room_Temperature': np.clip(np.random.normal(21, 2, n_samples), 16, 28),
        'Noise_Level': np.random.choice(['Low', 'Medium', 'High'], n_samples, p=[0.6, 0.3, 0.1]),
        'Caffeine_Intake': np.random.poisson(2, n_samples),
        'Alcohol_Consumption': np.random.choice(['None', 'Low', 'Moderate', 'High'], n_samples, p=[0.5, 0.3, 0.15, 0.05]),
        'Exercise_Frequency': np.random.choice(['None', '1-2', '3-4', '5+'], n_samples, p=[0.2, 0.4, 0.3, 0.1])
    })
    return data

def preprocess_data(df):
    column_mapping = {
        'weekendBedtimeHour': 'Weekend_Bedtime_Hour',
        'weekendBedtimeMinute': 'Weekend_Bedtime_Minute',
        'weekendWakeUpHour': 'Weekend_Wakeup_Hour',
        'weekendWakeUpMinute': 'Weekend_Wakeup_Minute',
        'Bedtime_Hour': 'Weekday_Bedtime_Hour',
        'Bedtime_Minute': 'Weekday_Bedtime_Minute',
        'Wakeup_Hour': 'Weekday_Wakeup_Hour',
        'Wakeup_Minute': 'Weekday_Wakeup_Minute',
        'useElectronicDevicesBeforeBed': 'Electronic_Devices_Before_Bed'
    }
    df = df.rename(columns={k: v for k, v in column_mapping.items() if k in df.columns})
    df['Has_Sleep_Disorder'] = df['Sleep_Disorder'].apply(lambda x: 0 if x == 'None' else 1)
    weekday_bedtime = df['Weekday_Bedtime_Hour'] + df['Weekday_Bedtime_Minute']/60
    weekend_bedtime = df['Weekend_Bedtime_Hour'] + df['Weekend_Bedtime_Minute']/60
    df['Sleep_Efficiency'] = df['Sleep_Duration'] / ((df['Weekday_Wakeup_Hour'] + df['Weekday_Wakeup_Minute']/60) - weekday_bedtime)
    df['Social_Jetlag'] = abs(weekend_bedtime - weekday_bedtime)
    df['Sleep_Regularity'] = 1 / (1 + df['Social_Jetlag'])
    df['Late_Night_Device_Use'] = df['Electronic_Devices_Before_Bed'] & (df['Weekday_Bedtime_Hour'] >= 23)
    df['Sleep_Time_Variability'] = df.apply(lambda row: abs((row['Weekend_Bedtime_Hour'] - row['Weekday_Bedtime_Hour']) + abs((row['Weekend_Wakeup_Hour'] - row['Weekday_Wakeup_Hour']))/60), axis=1)
    df['Sleep_Deficit'] = np.where(df['Sleep_Duration'] < 7, 7 - df['Sleep_Duration'], 0)
    df['Stress_Sleep_Interaction'] = df['Stress_Level'] * (8 - df['Sleep_Duration'])
    df['Circadian_Disruption'] = abs(weekend_bedtime - weekday_bedtime)
    df['Stress_Sleep_Ratio'] = df['Stress_Level'] / (df['Sleep_Duration'] + 1e-6)
    df['BMI_Numeric'] = df['BMI_Category'].map({'Underweight': 0, 'Normal': 1, 'Overweight': 2, 'Obese': 3})
    df['Alcohol_Numeric'] = df['Alcohol_Consumption'].map({'None': 0, 'Low': 1, 'Moderate': 2, 'High': 3})
    df['Exercise_Numeric'] = df['Exercise_Frequency'].map({'None': 0, '1-2': 1, '3-4': 2, '5+': 3})

    numerical_features = [
        'Age', 'Sleep_Duration', 'Physical_Activity', 'Heart_Rate',
        'Daily_Steps', 'Stress_Level', 'Sleep_Quality', 'Awakenings',
        'Room_Temperature', 'Caffeine_Intake', 'Sleep_Efficiency',
        'Social_Jetlag', 'Sleep_Regularity', 'Sleep_Time_Variability',
        'Sleep_Deficit', 'Stress_Sleep_Interaction',
        'BMI_Numeric', 'Alcohol_Numeric', 'Exercise_Numeric',
        'Circadian_Disruption', 'Stress_Sleep_Ratio'
    ]

    categorical_features = [
        'Gender', 'BMI_Category', 'Electronic_Devices_Before_Bed',
        'Late_Night_Device_Use', 'Noise_Level', 'Alcohol_Consumption',
        'Exercise_Frequency'
    ]

    preprocessor = ColumnTransformer(
        transformers=[
            ('num', StandardScaler(), numerical_features),
            ('cat', OneHotEncoder(handle_unknown='ignore', sparse_output=False), categorical_features)
        ]
    )

    X = df[numerical_features + categorical_features]
    y = df['Has_Sleep_Disorder']
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
    return X_train, X_test, y_train, y_test, preprocessor, numerical_features, categorical_features






def train_model(X_train, y_train, preprocessor):
    print("Training model without resampling to avoid threading issues...")

    # Step 1: Preprocess the data
    X_train_processed = preprocessor.fit_transform(X_train)
    
    print(f"Training data shape: {X_train.shape}")
    print(f"Class distribution: {np.bincount(y_train)}")

    # Step 2: Define models with parameters optimized for imbalanced data
    model_xgb = XGBClassifier(
        n_estimators=300,
        max_depth=6,
        learning_rate=0.1,
        scale_pos_weight=3.0,  # Handle class imbalance
        use_label_encoder=False, 
        eval_metric='logloss', 
        random_state=42
    )
    
    model_lgbm = LGBMClassifier(
        n_estimators=300,
        max_depth=6,
        learning_rate=0.1,
        class_weight='balanced',  # Handle class imbalance
        random_state=42
    )

    # Step 3: Train stacking classifier
    stacking_model = StackingClassifier(
        estimators=[('xgb', model_xgb), ('lgbm', model_lgbm)],
        final_estimator=LogisticRegression(class_weight='balanced'),
        cv=5
    )
    
    print("Training stacking classifier...")
    stacking_model.fit(X_train_processed, y_train)
    
    # Step 4: Create final pipeline
    final_pipeline = Pipeline([
        ('preprocessor', preprocessor),
        ('classifier', stacking_model)
    ])
    
    print("Model training completed!")
    return final_pipeline


def evaluate_model(model, X_test, y_test):
    print("\nEvaluating model performance...")
    y_pred = model.predict(X_test)
    y_proba = model.predict_proba(X_test)[:, 1]

    print("Accuracy:", accuracy_score(y_test, y_pred))
    print("F1 Score:", f1_score(y_test, y_pred))
    print("ROC AUC:", roc_auc_score(y_test, y_proba))
    print("Classification Report:\n", classification_report(y_test, y_pred))

    cm = confusion_matrix(y_test, y_pred)
    sns.heatmap(cm, annot=True, fmt='d')
    plt.title("Confusion Matrix")
    plt.savefig("confusion_matrix.png")
    plt.close()

    precision, recall, _ = precision_recall_curve(y_test, y_proba)
    plt.plot(recall, precision)
    plt.xlabel("Recall")
    plt.ylabel("Precision")
    plt.title("Precision-Recall Curve")
    plt.savefig("precision_recall.png")
    plt.close()

    prob_true, prob_pred = calibration_curve(y_test, y_proba, n_bins=10)
    plt.plot(prob_pred, prob_true, marker='o')
    plt.plot([0, 1], [0, 1], linestyle='--')
    plt.title("Calibration Curve")
    plt.savefig("calibration_curve.png")
    plt.close()

    try:
        import shap
        # Get the XGBoost model for feature importance
        estimators = model.named_steps['classifier'].estimators_
        xgb_model = None
        for name, estimator in estimators:
            if name == 'xgb':
                xgb_model = estimator
                break
        
        if xgb_model is not None:
            # Get feature names
            feature_names = []
            feature_names.extend(model.named_steps['preprocessor'].named_transformers_['num'].get_feature_names_out())
            feature_names.extend(model.named_steps['preprocessor'].named_transformers_['cat'].get_feature_names_out())
            
            # Plot feature importance
            importances = xgb_model.feature_importances_
            indices = np.argsort(importances)[::-1]
            
            plt.figure(figsize=(12, 8))
            plt.title("Feature Importance (XGBoost)")
            plt.bar(range(len(indices[:20])), importances[indices[:20]])
            plt.xticks(range(len(indices[:20])), [feature_names[i] for i in indices[:20]], rotation=45, ha='right')
            plt.tight_layout()
            plt.savefig("feature_importance_xgb.png", bbox_inches='tight', dpi=300)
            plt.close()
            print("Feature importance plot saved as feature_importance_xgb.png")
            
    except Exception as e:
        print("Feature importance analysis failed:", e)


def save_model(model, num_features, cat_features):
    joblib.dump({
        'model': model,
        'numerical_features': num_features,
        'categorical_features': cat_features
    }, MODEL_PATH)
    print("Model saved.")


def plot_xgb_feature_importance(X_train, y_train, preprocessor, feature_names=None):
    print("\nTraining single XGBoost model for feature importance analysis...")
    from xgboost import XGBClassifier
    import matplotlib.pyplot as plt
    import numpy as np

    X_train_processed = preprocessor.fit_transform(X_train)
    xgb = XGBClassifier(
        n_estimators=300,
        max_depth=6,
        learning_rate=0.1,
        scale_pos_weight=3.0,
        use_label_encoder=False,
        eval_metric='logloss',
        random_state=42
    )
    xgb.fit(X_train_processed, y_train)

    if feature_names is None:
        # Try to get feature names from preprocessor
        feature_names = []
        feature_names.extend(preprocessor.named_transformers_['num'].get_feature_names_out())
        feature_names.extend(preprocessor.named_transformers_['cat'].get_feature_names_out())

    importances = xgb.feature_importances_
    indices = np.argsort(importances)[::-1]

    plt.figure(figsize=(12, 8))
    plt.title("Feature Importance (XGBoost)")
    plt.bar(range(len(indices[:20])), importances[indices[:20]])
    plt.xticks(range(len(indices[:20])), [feature_names[i] for i in indices[:20]], rotation=45, ha='right')
    plt.tight_layout()
    plt.savefig("feature_importance_xgb.png", bbox_inches='tight', dpi=300)
    plt.close()
    print("Feature importance plot saved as feature_importance_xgb.png")


def main():
    print("=== Sleep Disorder Model Training ===")
    df = get_dataset()
    X_train, X_test, y_train, y_test, preprocessor, num_feats, cat_feats = preprocess_data(df)
    model = train_model(X_train, y_train, preprocessor)
    evaluate_model(model, X_test, y_test)
    save_model(model, num_feats, cat_feats)
    # Plot feature importance using single XGBoost model
    plot_xgb_feature_importance(X_train, y_train, preprocessor)


if __name__ == '__main__':
    main()
