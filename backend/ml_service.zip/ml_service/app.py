import os
import numpy as np
import pandas as pd
from flask import Flask, request, jsonify
from flask_cors import CORS
import datetime
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
import joblib
import json
import datetime
import logging
import requests
from typing import Dict, List, Any, Tuple, Union
from sleep_prediction_service import SleepPredictionService

app = Flask(__name__)
CORS(app, resources={r"/*": {"origins": "*"}})

# Health check endpoint

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Path to save/load the model
MODEL_PATH = os.path.join(os.path.dirname(__file__), 'sleep_model.pkl')

# Define feature columns for our model based on Sleep Health Dataset
# These will be overridden when loading the model but defined here as fallback
NUMERICAL_FEATURES = [
    'Age', 'Sleep Duration', 'Physical Activity Level', 'Heart Rate', 'Daily Steps', 'Stress Level',
    'Weekday Bedtime Hour', 'Weekday Bedtime Minute', 'Weekday Wake-up Hour', 'Weekday Wake-up Minute',
    'Weekend Bedtime Hour', 'Weekend Bedtime Minute', 'Weekend Wake-up Hour', 'Weekend Wake-up Minute',
    'Awakenings During Night', 'Rate Sleep Quality', 'How Relaxed Before Sleep',
    'Breakfast Time Hour', 'Breakfast Time Minute', 'Breakfast Portion Size',
    'Lunch Time Hour', 'Lunch Time Minute', 'Lunch Portion Size',
    'Dinner Time Hour', 'Dinner Time Minute', 'Dinner Portion Size',
    'No. of Meals Per Day', 'Light Intensity', 'Temperature',
    'Caffeine Intake', 'Sleep Efficiency', 'Social Jetlag', 'Sleep Regularity'
]

CATEGORICAL_FEATURES = [
    'Gender', 'BMI Category',
    'Use Electronic Devices Before Bed', 'Take Breakfast', 'Breakfast Food Type',
    'Do Lunch', 'Lunch Food Type', 'Have Dinner', 'Dinner Food Type',
    'Sound Exposure',
    'Late Night Device Use', 'Alcohol Consumption', 'Exercise Frequency'
]

ALL_FEATURES = NUMERICAL_FEATURES + CATEGORICAL_FEATURES

# Initialize or load model
def get_model():
    # Capture a copy of the initial global feature definitions from the script
    # These are the features we want preprocess_input and calculate_contributing_factors to always consider.
    initial_numerical_features = [
        'Age', 'Sleep Duration', 'Physical Activity Level', 
        'Heart Rate', 'Daily Steps', 'Stress Level',
        'Weekday Bedtime Hour', 'Weekday Bedtime Minute', 'Weekday Wake-up Hour', 'Weekday Wake-up Minute',
        'Weekend Bedtime Hour', 'Weekend Bedtime Minute', 'Weekend Wake-up Hour', 'Weekend Wake-up Minute',
        'Awakenings During Night', 'Rate Sleep Quality', 'How Relaxed Before Sleep',
        'Breakfast Time Hour', 'Breakfast Time Minute', 'Breakfast Portion Size',
        'Lunch Time Hour', 'Lunch Time Minute', 'Lunch Portion Size',
        'Dinner Time Hour', 'Dinner Time Minute', 'Dinner Portion Size',
        'No. of Meals Per Day', 
        'Light Intensity', 'Temperature',
        'Caffeine Intake', 'Sleep Efficiency', 'Social Jetlag', 'Sleep Regularity'
    ]
    initial_categorical_features = [
        'Gender', 'BMI Category',
        'Use Electronic Devices Before Bed', 'Take Breakfast', 'Breakfast Food Type',
        'Do Lunch', 'Lunch Food Type', 'Have Dinner', 'Dinner Food Type',
        'Sound Exposure',
        'Late Night Device Use', 'Alcohol Consumption', 'Exercise Frequency'
    ]
    initial_all_features = initial_numerical_features + initial_categorical_features

    global NUMERICAL_FEATURES, CATEGORICAL_FEATURES, ALL_FEATURES
    model_to_return = None
    model_expected_features = [] # List of features the loaded model pipeline strictly expects

    # Set global feature lists to the comprehensive initial script definitions.
    # preprocess_input and calculate_contributing_factors will use these.
    NUMERICAL_FEATURES = initial_numerical_features[:]
    CATEGORICAL_FEATURES = initial_categorical_features[:]
    ALL_FEATURES = initial_all_features[:]
    logger.info(f"Global feature lists reset to initial script definitions. ALL_FEATURES count: {len(ALL_FEATURES)}")

    if os.path.exists(MODEL_PATH):
        logger.info(f"Loading existing model from {MODEL_PATH}...")
        try:
            model_info = joblib.load(MODEL_PATH)
            if isinstance(model_info, dict):
                model_to_return = model_info['model']
                # Determine features the loaded model was strictly trained on
                loaded_model_numerical_f = model_info.get('numerical_features', [])
                loaded_model_categorical_f = model_info.get('categorical_features', [])
                model_expected_features = loaded_model_numerical_f + loaded_model_categorical_f
                if not model_expected_features: # If lists in model_info are empty or not present
                    logger.warning("Model file's feature lists are empty. Model will expect features based on initial script definitions.")
                    model_expected_features = initial_all_features[:]
                logger.info(f"Model loaded from file. Model's prediction pipeline expects {len(model_expected_features)} features: {model_expected_features}")
            else: # model_info is just the model object, no feature metadata
                model_to_return = model_info
                model_expected_features = initial_all_features[:] # Model expects features based on initial script definitions
                logger.warning("Model file did not contain feature dictionary. Model will expect features based on initial script definitions for prediction.")
                logger.info(f"Model expects {len(model_expected_features)} features: {model_expected_features}")
        except Exception as e:
            logger.error(f"Error loading model: {str(e)}. Creating fallback model.")
            model_to_return = create_fallback_model()
            model_expected_features = initial_all_features[:] # Fallback model expects features based on initial script definitions
            logger.info(f"Using fallback model. Model expects {len(model_expected_features)} features: {model_expected_features}")
    else:
        logger.warning(f"No model found at {MODEL_PATH}. Creating fallback model...")
        model_to_return = create_fallback_model()
        model_expected_features = initial_all_features[:] # Fallback model expects features based on initial script definitions
        logger.info(f"Using fallback model. Model expects {len(model_expected_features)} features: {model_expected_features}")

    # 'No. of Meals Per Day' is already in initial_numerical_features and initial_all_features
    # So, the global ALL_FEATURES used by preprocess_input will contain it.
    # No explicit addition needed here if it's part of the initial script definition.
    logger.info(f"Final global ALL_FEATURES (for preprocessing/factors): {ALL_FEATURES} (Count: {len(ALL_FEATURES)})")
    logger.info(f"Model will be returned with expectation of {len(model_expected_features)} features for its direct input: {model_expected_features}")

    return model_to_return, model_expected_features

def create_fallback_model():
    """Create a simple model for when the trained model is not available"""
    logger.info("Creating fallback model...")
    
    # Define preprocessing for numerical features
    numerical_transformer = Pipeline(steps=[
        ('scaler', StandardScaler())
    ])
    
    # Define preprocessing for categorical features
    categorical_transformer = Pipeline(steps=[
        ('onehot', OneHotEncoder(handle_unknown='ignore'))
    ])
    
    # Combine preprocessing steps
    preprocessor = ColumnTransformer(
        transformers=[
            ('num', numerical_transformer, NUMERICAL_FEATURES),
            ('cat', categorical_transformer, CATEGORICAL_FEATURES)
        ])
    
    # Create and return the model pipeline
    model = Pipeline(steps=[
        ('preprocessor', preprocessor),
        ('classifier', RandomForestClassifier(n_estimators=100, random_state=42))
    ])
    
    logger.warning("Using untrained fallback model. Please train a proper model using train_model.py")
    return model

# Initialize model
model, model_expected_features = get_model()

def preprocess_input(data: Dict[str, Any]) -> Dict[str, Any]:
    """Process input data from the request into model-compatible format"""
    logger.info(f"ALL_FEATURES at start of preprocess_input: {ALL_FEATURES}") # Log ALL_FEATURES

    # Map common input key variations (e.g., from PowerShell) to canonical space-separated names
    input_key_mapping = {
        'Sleep_Duration': 'Sleep Duration',
        'Physical_Activity': 'Physical Activity Level',
        'Heart_Rate': 'Heart Rate',
        'Daily_Steps': 'Daily Steps',
        'Stress_Level': 'Stress Level',
        'Sleep_Quality': 'Rate Sleep Quality',
        'Awakenings': 'Awakenings During Night',
        'Room_Temperature': 'Temperature',
        'Electronic_Devices_Before_Bed': 'Use Electronic Devices Before Bed',
        'Noise_Level': 'Sound Exposure',
        'Caffeine_Intake': 'Caffeine Intake',
        'Sleep_Efficiency': 'Sleep Efficiency',
        'Social_Jetlag': 'Social Jetlag',
        'Sleep_Regularity': 'Sleep Regularity',
        'Late_Night_Device_Use': 'Late Night Device Use',
        'Alcohol_Consumption': 'Alcohol Consumption',
        'Exercise_Frequency': 'Exercise Frequency'
        # Add other direct model_expected_features if they differ from canonical names
    }
    
    mapped_data = {}
    for key, value in data.items():
        mapped_data[input_key_mapping.get(key, key)] = value
    data = mapped_data # Use the mapped data for further processing

    processed_data = {}
    
    # Directly map input data fields that match ALL_FEATURES names
    # This assumes the input JSON keys are the same as the feature names in ALL_FEATURES.
    for feature_name in ALL_FEATURES:
        if feature_name == 'No. of Meals Per Day': # Specific check for debugging
            logger.info(f"Preprocessing: Checking for '{feature_name}'. Is it in input data? {'Yes' if feature_name in data else 'No'}")
        if feature_name in data:  # 'data' is the input JSON dictionary
            processed_data[feature_name] = data[feature_name]

    # Specific transformations for boolean fields to string 'Yes'/'No'
    # The model's OneHotEncoder likely expects string categories.
    boolean_to_string_features = ['Use Electronic Devices Before Bed', 'Late Night Device Use'] # Use canonical space-separated names
    for feature in boolean_to_string_features:
        if feature in processed_data and isinstance(processed_data[feature], bool):
            processed_data[feature] = 'Yes' if processed_data[feature] else 'No'

    # Note: The 'Noise_Level' feature is expected to be a string like 'Low', 'Medium', 'High'.
    # If the input provides it as such, no further transformation is needed here.
    # If it were numeric, a transformation similar to the old 'noiseLevel' logic would be required.
    
    # Handle missing required features with reasonable defaults
    for feature in ALL_FEATURES:
        if feature not in processed_data:
            if feature == 'Age':
                processed_data[feature] = 35  # Default age
            elif feature == 'Gender':
                processed_data[feature] = 'Male'  # Default gender
            elif feature == 'BMI Category':
                processed_data[feature] = 'Normal'  # Default BMI
            elif feature == 'Sleep Duration':
                processed_data[feature] = 7.0  # Default sleep hours
            elif feature == 'Physical Activity Level':
                processed_data[feature] = 45  # Default minutes of activity
            elif feature == 'Heart Rate':
                processed_data[feature] = 70  # Default BPM
            elif feature == 'Daily Steps':
                processed_data[feature] = 7000  # Default steps
            elif feature == 'Stress Level':
                processed_data[feature] = 5  # Default stress (1-10)
            
            # Sleep Patterns Defaults
            elif feature == 'Weekday Bedtime Hour': processed_data[feature] = 22
            elif feature == 'Weekday Bedtime Minute': processed_data[feature] = 0
            elif feature == 'Weekday Wake-up Hour': processed_data[feature] = 7
            elif feature == 'Weekday Wake-up Minute': processed_data[feature] = 0
            elif feature == 'Weekend Bedtime Hour': processed_data[feature] = 23
            elif feature == 'Weekend Bedtime Minute': processed_data[feature] = 0
            elif feature == 'Weekend Wake-up Hour': processed_data[feature] = 9
            elif feature == 'Weekend Wake-up Minute': processed_data[feature] = 0
            elif feature == 'Awakenings During Night': processed_data[feature] = 1
            elif feature == 'Rate Sleep Quality': processed_data[feature] = 3
            elif feature == 'Use Electronic Devices Before Bed': processed_data[feature] = 'No'  # Default to string 'No'
            elif feature == 'How Relaxed Before Sleep': processed_data[feature] = 3

            # Dietary Habits Defaults
            elif feature == 'Take Breakfast': processed_data[feature] = True
            elif feature == 'Breakfast Time Hour': processed_data[feature] = 8
            elif feature == 'Breakfast Time Minute': processed_data[feature] = 0
            elif feature == 'Breakfast Food Type': processed_data[feature] = 'Proteins'
            elif feature == 'Breakfast Portion Size': processed_data[feature] = 300
            elif feature == 'Do Lunch': processed_data[feature] = True
            elif feature == 'Lunch Time Hour': processed_data[feature] = 13
            elif feature == 'Lunch Time Minute': processed_data[feature] = 0
            elif feature == 'Lunch Food Type': processed_data[feature] = 'Carbohydrates'
            elif feature == 'Lunch Portion Size': processed_data[feature] = 400
            elif feature == 'Have Dinner': processed_data[feature] = True
            elif feature == 'Dinner Time Hour': processed_data[feature] = 20
            elif feature == 'Dinner Time Minute': processed_data[feature] = 0
            elif feature == 'Dinner Food Type': processed_data[feature] = 'Proteins'
            elif feature == 'Dinner Portion Size': processed_data[feature] = 400
            elif feature == 'No. of Meals Per Day': processed_data[feature] = 3

            # Environmental Factors Defaults
            elif feature == 'Light Intensity': processed_data[feature] = 300
            elif feature == 'Temperature': processed_data[feature] = 22
            elif feature == 'Sound Exposure': processed_data[feature] = 'Moderate (30-60 dB)'
            # Defaults for added model features (now space-separated)
            elif feature == 'Caffeine Intake': processed_data[feature] = 0
            elif feature == 'Sleep Efficiency': processed_data[feature] = 0.85
            elif feature == 'Social Jetlag': processed_data[feature] = 0.5
            elif feature == 'Sleep Regularity': processed_data[feature] = 0.8
            elif feature == 'Late Night Device Use': processed_data[feature] = 'No'
            elif feature == 'Alcohol Consumption': processed_data[feature] = 'None'
            elif feature == 'Exercise Frequency': processed_data[feature] = 'Occasionally'
    
    logger.info(f"Processed input: {processed_data}")
    return processed_data

# Train the model with sample data if it's newly created
def initialize_model_with_sample_data():
    if not os.path.exists(MODEL_PATH):
        print("Training model with sample data...")
        
        # Create synthetic sample data
        np.random.seed(42)
        n_samples = 200
        
        # Generate random values for features
        data = {
            'Age': np.random.uniform(20, 60, n_samples),
            'Gender': np.random.choice(['Male', 'Female'], n_samples),
            'BMI Category': np.random.choice(['Underweight', 'Normal', 'Overweight', 'Obese'], n_samples),
            'Sleep Duration': np.random.uniform(5, 10, n_samples),
            'Physical Activity Level': np.random.uniform(30, 90, n_samples),
            'Heart Rate': np.random.uniform(60, 100, n_samples),
            'Daily Steps': np.random.uniform(5000, 15000, n_samples),
            'Stress Level': np.random.uniform(1, 10, n_samples),
        }
        
        # Generate target variables: sleep quality (0-10) and interruption count
        base_quality = 7.0
        noise = np.random.normal(0, 1, n_samples)
        
        # Sleep quality decreases with age, stress, and increases with physical activity
        quality_adjustments = (
            -0.01 * (data['Age'] - 30) 
            + 0.01 * data['Physical Activity Level'] 
            - 0.1 * data['Stress Level']
        )
        
        # Adjustments for categorical variables
        gender_adj = np.where(data['Gender'] == 'Female', 0.5, -0.5)
        bmi_adj = np.zeros(n_samples)
        bmi_adj[data['BMI Category'] == 'Underweight'] = -0.5
        bmi_adj[data['BMI Category'] == 'Overweight'] = -0.3
        bmi_adj[data['BMI Category'] == 'Obese'] = -0.8
        
        # Combine all adjustments
        sleep_quality = base_quality + quality_adjustments + gender_adj + bmi_adj + noise
        sleep_quality = np.clip(sleep_quality, 0, 10)  # Ensure it's within 0-10 range
        
        # Calculate interruption count based on similar factors
        interruption_base = 2
        interruption_adj = (
            0.01 * (data['Age'] - 30)
            - 0.01 * data['Physical Activity Level']
            + 0.1 * data['Stress Level']
        )
        interruption_count = interruption_base + interruption_adj + np.random.normal(0, 0.5, n_samples)
        interruption_count = np.clip(interruption_count, 0, 10).astype(int)
        
        # Create a DataFrame with all features and targets
        df = pd.DataFrame(data)
        df['sleep_quality'] = sleep_quality
        df['interruption_count'] = interruption_count
        
        # Split into features and targets
        X = df[ALL_FEATURES]
        y_quality = df['sleep_quality']
        y_interruptions = df['interruption_count']
        
        # Train model for sleep quality prediction
        model.fit(X, y_quality)
        
        # Save the model
        joblib.dump(model, MODEL_PATH)
        
        return model
    
    return model

# Initialize with sample data if needed
model = initialize_model_with_sample_data()

@app.route('/health', methods=['GET'])
def health_check():
    return jsonify({'status': 'healthy', 'timestamp': datetime.datetime.now().isoformat()})

def generate_sleep_analysis(features, prediction_score, user_name, user_age, user_gender):
    """Generate detailed sleep analysis based on user data and prediction score"""
    analysis = []
    
    # Personalized greeting with name
    analysis.append(f"Hello {user_name}! Here's your personalized sleep analysis:")
    analysis.append("="*50)
    
    # Age and gender specific considerations
    age = features.get('Age', user_age)
    gender = features.get('Gender', user_gender).lower()
    
    # Basic sleep duration analysis with age and gender context
    sleep_duration = features.get('Sleep Duration', 0)
    if age >= 18 and age <= 64:
        if sleep_duration < 7:
            analysis.append(f"At {age} years old, you're getting {sleep_duration:.1f} hours of sleep, which is below the recommended 7-9 hours for adults.")
        elif sleep_duration > 9:
            analysis.append(f"At {age} years old, you're getting {sleep_duration:.1f} hours of sleep, which is more than the recommended amount for adults.")
        else:
            analysis.append(f"Your sleep duration of {sleep_duration:.1f} hours is within the recommended range for adults.")
    else:
        analysis.append(f"Your current sleep duration is {sleep_duration:.1f} hours.")
    
    # Gender-specific considerations
    if gender == 'female':
        analysis.append("As a woman, you might experience sleep pattern variations due to hormonal changes. "
                      "This is normal but can affect sleep quality.")
    
    # Sleep quality analysis with personalized tips
    sleep_quality = features.get('Rate Sleep Quality', 3)
    if sleep_quality < 3:
        analysis.append(f"Your reported sleep quality is below average. Let's work on improving this, {user_name}!")
    elif sleep_quality > 3:
        analysis.append("Great job! Your reported sleep quality is above average.")
    
    # Environmental factors with personalized recommendations
    if features.get('Use Electronic Devices Before Bed', False):
        analysis.append(f"{user_name}, using electronic devices before bed is affecting your sleep quality due to blue light exposure. "
                      "Try using blue light filters or avoiding screens 1 hour before bed.")
    
    sound_level = features.get('Sound Exposure', '')
    if 'Loud' in sound_level:
        analysis.append("The noise levels in your environment might be disrupting your sleep. Consider using earplugs or white noise.")
    
    # Dietary factors with timing considerations
    dinner_time_hour = features.get('Dinner Time Hour', 20)
    if dinner_time_hour >= 21:
        analysis.append(f"{user_name}, eating dinner at {dinner_time_hour}:00 is quite late and might be affecting your sleep quality. "
                      "Try to have dinner at least 2-3 hours before bedtime.")
    
    # Age-specific recommendations
    if age > 50:
        analysis.append("As we get older, sleep patterns naturally change. You might find it helpful to maintain a consistent sleep schedule.")
    
    return analysis

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get data from request
        data = request.get_json()
        logger.info(f"Received prediction request with data: {data}")
        
        # Get user's name if provided
        user_name = data.get('userName', 'there')
        
        # The following lines for combined_data are for a nested structure not currently used by tests.
        # sleep_data = data.get('sleepData', {})
        # environmental_data = data.get('environmentalData', {})
        # dietary_data = data.get('dietaryData', {})
        # combined_data = {}
        # combined_data.update(sleep_data)
        # combined_data.update(environmental_data)
        # combined_data.update(dietary_data)
        
        # Pass the raw 'data' (from request.get_json()) directly
        # as the current tests use a flat JSON structure.
        processed_data = preprocess_input(data)
        logger.info(f"Full processed data (for factors/recommendations): {processed_data}")

        # Prepare data specifically for the model, using only the features it expects
        # and ensuring they are in the order the model was trained on.

        # Mapping from model_expected_features (keys from .pkl, often with underscores)
        # to the keys in processed_data (script-defined, often with spaces)
        feature_name_map_for_model = {
            # Model's underscore_name : Canonical space-separated name in processed_data
            'Sleep_Duration': 'Sleep Duration',
            'Physical_Activity': 'Physical Activity Level',
            'Heart_Rate': 'Heart Rate',
            'Daily_Steps': 'Daily Steps',
            'Stress_Level': 'Stress Level',
            'Sleep_Quality': 'Rate Sleep Quality',
            'Awakenings': 'Awakenings During Night',
            'Room_Temperature': 'Temperature',
            'Electronic_Devices_Before_Bed': 'Use Electronic Devices Before Bed',
            'Noise_Level': 'Sound Exposure',
            'Age': 'Age',
            'Gender': 'Gender',
            'BMI_Category': 'BMI Category',
            'Caffeine_Intake': 'Caffeine Intake',
            'Sleep_Efficiency': 'Sleep Efficiency',
            'Social_Jetlag': 'Social Jetlag',
            'Sleep_Regularity': 'Sleep Regularity',
            'Late_Night_Device_Use': 'Late Night Device Use',
            'Alcohol_Consumption': 'Alcohol Consumption',
            'Exercise_Frequency': 'Exercise Frequency',
            'No. of Meals Per Day': 'No. of Meals Per Day'
        }

        data_for_model_prediction = {}
        for model_feature_name in model_expected_features:
            script_feature_name = feature_name_map_for_model.get(model_feature_name, model_feature_name)
            data_for_model_prediction[model_feature_name] = processed_data.get(script_feature_name)
            if data_for_model_prediction[model_feature_name] is None:
                logger.warning(f"Feature '{script_feature_name}' (mapped from '{model_feature_name}') not found in processed_data or is None. Model will receive None/NaN.")

        input_df_for_prediction = pd.DataFrame([data_for_model_prediction], columns=model_expected_features)

        logger.info(f"Data being sent to model.predict_proba (shape {input_df_for_prediction.shape}, columns: {input_df_for_prediction.columns.tolist()}):\n{input_df_for_prediction.head().to_string()}")

        # Generate predictions
        try:
            # Make prediction with the model
            prediction_proba = model.predict_proba(input_df_for_prediction)
            # Get probability of good sleep (assuming class 0 is good sleep)
            good_sleep_prob = prediction_proba[0][0] if len(prediction_proba[0]) > 1 else 0.7
            sleep_disorder_prob = 1 - good_sleep_prob
            logger.info(f"Good sleep probability: {good_sleep_prob}, Disorder probability: {sleep_disorder_prob}")
            
            # Calculate sleep quality score (0-10 scale)
            sleep_quality_score = good_sleep_prob * 10
            
        except Exception as e:
            logger.error(f"Error during model prediction: {str(e)}")
            logger.error(f"Model expected features: {model_expected_features}")
            logger.error(f"Features passed to model: {input_df_for_prediction.columns.tolist()}")
            # Fallback or default prediction values
            prediction_label = "⚠️ Error! Prediction unavailable."
            probabilities = np.array([[0.5, 0.5]]) # Neutral probabilities on error
            good_sleep_prob = 0.5 # Default good sleep probability
            sleep_disorder_prob = 0.5 # Default disorder probability
            prediction_score = 5.0 # Neutral score
            normalized_score = 0.50
        
        # Calculate contributing factors
        contributing_factors = calculate_contributing_factors(processed_data)
        logger.info(f"Calculated contributing factors: {contributing_factors}")
        
        # ... (rest of the code remains the same)
        # Generate personalized recommendations
        # Pass user_name to generate_recommendations
        recommendations = generate_recommendations(processed_data, contributing_factors, user_name)
        logger.info(f"Generated recommendations: {recommendations}")
        
        # Generate sleep interruption windows based on the disorder probability
        interruption_windows = []
        if sleep_disorder_prob > 0.3:  # Only predict interruptions for higher probability of sleep disorder
            num_interruptions = max(1, int(sleep_disorder_prob * 5))  # Scale by probability
            for i in range(num_interruptions):
                # Generate times between 11 PM and 6 AM
                hour = np.random.randint(23, 29) % 24
                minute = np.random.randint(0, 60)
                duration = np.random.randint(10, 30)  # Duration in minutes
                
                start_time = f"{hour:02d}:{minute:02d}"
                end_minute = (minute + duration) % 60
                end_hour = (hour + (minute + duration) // 60) % 24
                end_time = f"{end_hour:02d}:{end_minute:02d}"
                
                interruption_windows.append({
                    "startTime": start_time,
                    "endTime": end_time,
                    "probability": round(0.4 + (sleep_disorder_prob * 0.5), 2)  # Scale probability by disorder probability
                })
        
        # Get user details
        user_age = int(processed_data.get('Age', 30))  # Default to 30 if not provided
        user_gender = processed_data.get('Gender', 'User')  # Default to 'User' if not provided
        
        # Generate detailed analysis with personalized insights
        sleep_analysis = generate_sleep_analysis(processed_data, good_sleep_prob, user_name, user_age, user_gender)
        
        # Format the analysis with proper spacing
        analysis_text = "\n\n".join(sleep_analysis)
        
        # Add prediction summary with emoji for better readability
        score = round(good_sleep_prob * 10, 1)
        if score >= 8:
            emoji = "😊"
            summary = "Excellent!"
        elif score >= 6:
            emoji = "🙂"
            summary = "Good job!"
        else:
            emoji = "😴"
            summary = "Let's improve this!"
            
        prediction_summary = f"\n\n📊 Sleep Quality Score: {score}/10 {emoji}\n{summary}"
        
        # Calculate sleep duration in hours and minutes
        def format_duration(hours, minutes):
            if hours > 0 and minutes > 0:
                return f"{hours} hours and {minutes} minutes"
            elif hours > 0:
                return f"{hours} hours"
            else:
                return f"{minutes} minutes"
        
        # Calculate sleep duration from input data
        sleep_duration = processed_data.get('Sleep Duration', 7)  # Default to 7 hours if not provided
        
        # If we need to calculate it from bed/wake times
        if 'weekdayBedtimeHour' in processed_data and 'weekdayWakeUpHour' in processed_data:
            bedtime = datetime.time(
                hour=processed_data.get('weekdayBedtimeHour', 23),
                minute=processed_data.get('weekdayBedtimeMinute', 0)
            )
            wakeup = datetime.time(
                hour=processed_data.get('weekdayWakeUpHour', 7),
                minute=processed_data.get('weekdayWakeUpMinute', 0)
            )
            
            bedtime_dt = datetime.datetime.combine(datetime.date.today(), bedtime)
            wakeup_dt = datetime.datetime.combine(
                datetime.date.today() + datetime.timedelta(days=1) 
                if bedtime > wakeup 
                else datetime.date.today(), 
                wakeup
            )
            sleep_duration = (wakeup_dt - bedtime_dt).total_seconds() / 3600
        
        # Get user data for analysis (user_name is already extracted from raw 'data')
        sleep_duration = processed_data.get('Sleep Duration', 6.5) # Use key from processed_data
        awakenings = processed_data.get('Awakenings During Night', 0) # Use key from processed_data
        stress_level = processed_data.get('Stress Level', 5) # Use key from processed_data
        temperature = processed_data.get('Temperature', 22) # Use key from processed_data
        sound_level = processed_data.get('Sound Exposure', 'Low').lower() # Use key from processed_data
        
        # Generate prediction message
        score = round(good_sleep_prob * 10, 1)
        if score >= 8:
            prediction_message = "😊 Excellent! Your sleep quality is great!"
        elif score >= 6:
            prediction_message = "🙂 Good! Your sleep quality is decent but can be improved."
        else:
            prediction_message = "😴 Your sleep quality needs attention. Let's work on it!"
        
        # Generate detailed analysis
        analysis_parts = []
        
        # Sleep duration analysis
        if sleep_duration < 7:
            analysis_parts.append(f"You're averaging only {sleep_duration} hours of sleep on weekdays (slightly below the recommended 7-9 hours).")
        else:
            analysis_parts.append(f"Your sleep duration of {sleep_duration} hours is within the healthy range.")
        
        # Sleep quality factors
        if awakenings > 1:
            analysis_parts.append(f"You experience {awakenings} awakenings per night, which can disrupt your sleep cycles.")
            
        if processed_data.get('Electronic_Devices_Before_Bed', 'No') == 'Yes': # Corrected key and check
            analysis_parts.append("Using electronic devices before bed may be affecting your ability to fall asleep.")
            
        if stress_level > 6:
            analysis_parts.append(f"Your stress level is {stress_level}/10, which might be impacting your sleep quality.")
        
        # Environmental factors
        if temperature > 22:
            analysis_parts.append(f"Your room temperature of {temperature}°C is slightly above the ideal range of 16-20°C for optimal sleep.")
            
        if 'moderate' in sound_level or 'loud' in sound_level:
            analysis_parts.append("The noise levels in your environment might be affecting your sleep quality.")
        
        # Join analysis parts
        detailed_analysis = "We've analyzed your sleep data and found several factors that may affect your rest. " + " ".join(analysis_parts)
        logger.info(f"Generated detailed analysis: {detailed_analysis}")

        # Prepare response with all data
        response = {
            'prediction': prediction_message,
            'detailedAnalysis': detailed_analysis,
            'sleepDisorderProbability': round(sleep_disorder_prob, 2),
            'recommendations': recommendations,
            'predictionScore': round(score, 1),
            'normalizedScore': round(score / 10, 2),
            'predictedInterruptionCount': len(interruption_windows),
            'predictedInterruptionWindows': interruption_windows,
            'contributingFactors': contributing_factors,
            'timestamp': datetime.datetime.now().isoformat()
        }
        logger.info(f"Final response object: {response}")
        
        logger.info(f"Returning prediction response: {json.dumps(response)}")
        return jsonify(response)
    
    except Exception as e:
        logger.error(f"Critical error in /predict endpoint: {str(e)}", exc_info=True)
        return jsonify({
            "error": "Prediction failed due to an internal server error.",
            "details": str(e),
            "prediction": "⚠️ Prediction unavailable",
            "detailedAnalysis": "Analysis unavailable due to error.",
            "sleepDisorderProbability": 0.5,
            "recommendations": ["Recommendations unavailable due to error."],
            "predictionScore": 5.0,
            "normalizedScore": 0.5,
            "predictedInterruptionCount": 0,
            "predictedInterruptionWindows": [],
            "contributingFactors": {},
            "timestamp": datetime.datetime.now().isoformat()
        }), 500
def calculate_contributing_factors(features):
    """Calculate how much each feature contributes to sleep quality based on input features.
        Returns a dictionary with factor names compatible with the graph screenshot.
    """
    final_factors = {}
    
    # 1. Midnight Awakenings
    awakenings = features.get('Awakenings During Night', 0)
    if awakenings >= 3:
        final_factors['Midnight Awakenings'] = 0.8
    elif awakenings == 2:
        final_factors['Midnight Awakenings'] = 0.5
    elif awakenings == 1:
        final_factors['Midnight Awakenings'] = 0.2
    
    # 2. Device Use (blue light exposure)
    if features.get('Use Electronic Devices Before Bed', 'No').lower() == 'yes': 
        final_factors['Device Use'] = 0.6
    
    # 3. Dietary Variety (Proxy: Number of meals)
    num_meals = features.get('No. of Meals Per Day', 3) 
    if num_meals == 1:
        final_factors['Dietary Variety'] = 0.7
    elif num_meals == 2:
        final_factors['Dietary Variety'] = 0.3
    elif num_meals == 3:
        final_factors['Dietary Variety'] = 0.1 # Tentative: 3 meals is generally okay
        
    # 4. Temperature
    temperature = features.get('Temperature', 20.0) 
    if temperature > 25:
        final_factors['High Temperature'] = 0.9
    elif temperature > 22:
        final_factors['High Temperature'] = 0.5
    elif temperature < 16:
        final_factors['High Temperature'] = 0.7 
    elif temperature < 18:
        final_factors['High Temperature'] = 0.4

    # 5. Noise Level
    sound_exposure = features.get('Sound Exposure', 'Low').lower() 
    if 'loud' in sound_exposure:
        final_factors['Noise Level'] = 0.9
    elif 'moderate' in sound_exposure or sound_exposure == 'medium': # Corrected from 'medium' to 'moderate'
        final_factors['Noise Level'] = 0.5
        
    # Return only factors that have a calculated impact > 0, rounded to 2 decimal places.
    return {k: round(v, 2) for k, v in final_factors.items() if v > 0}
def generate_recommendations(features, factors, user_name="there"):
    """Generate personalized recommendations based on contributing factors"""
    recommendations = []
    # user_name is now passed as an argument
    
    # Sort factors by contribution value (highest first)
    sorted_factors = sorted(factors.items(), key=lambda x: x[1], reverse=True)
    
    # Generate targeted recommendations based on contributing factors
    for factor_name, factor_value in sorted_factors:
        if factor_value >= 0.2: # Threshold for recommendation
            if factor_name == 'Midnight Awakenings':
                recommendations.append(f"Try to reduce nighttime awakenings. You reported {features.get('Awakenings During Night', 0)} awakening(s).")
            elif factor_name == 'Device Use':
                recommendations.append("Reduce device usage at least 1 hour before bed to minimize blue light exposure.")
            elif factor_name == 'Dietary Variety':
                recommendations.append("Add more variety to your meals with fruits, vegetables, and whole grains.")
            elif factor_name == 'High Temperature':
                temp = features.get('Room_Temperature', 22)
                if temp > 22:
                    recommendations.append(f"Your room temperature ({temp}°C) is warm. Aim for 16-20°C for better sleep.")
                elif temp < 18:
                    recommendations.append(f"Your room temperature ({temp}°C) is cold. Aim for 16-20°C for better sleep.")
            elif factor_name == 'Noise Level':
                noise = features.get('Noise_Level', 'Low')
                if noise.lower() != 'low':
                    recommendations.append(f"Your environment has a '{noise}' noise level. Consider earplugs or white noise if it's disruptive.")
            # The following factors are not yet produced by calculate_contributing_factors:
            # elif factor_name == 'High Stress':
            #     recommendations.append("Practice relaxation techniques like deep breathing or meditation before bed.")
            # elif factor_name == 'High Caffeine Intake':
            #     recommendations.append("Avoid caffeine, especially in the afternoon and evening.")
    
    # Add general recommendations if we need more
    general_recommendations = [
        "Maintain a consistent sleep schedule, even on weekends.",
        "Create a relaxing bedtime routine to signal your body it's time to sleep.",
        "Avoid large meals, alcohol, and nicotine close to bedtime.",
        "Get regular exercise, but finish at least 3 hours before bed.",
        "Make sure your bedroom is dark, quiet, and at a comfortable temperature.",
        "Expose yourself to natural light during the day to regulate your sleep-wake cycle.",
        "Consider using blackout curtains or a sleep mask if your room isn't dark enough.",
        "If you can't sleep, get out of bed and do something relaxing until you feel sleepy.",
        "Limit daytime naps to 20-30 minutes to avoid disrupting nighttime sleep.",
        "Try to resolve worries or concerns before bedtime by making a to-do list for the next day."
    ]
    
    # Add general recommendations until we have 5-7 total
    for rec in general_recommendations:
        if rec not in recommendations:
            recommendations.append(rec)
            if len(recommendations) >= 7:  # Aim for 5-7 recommendations
                break
    
    # Format the final recommendations message
    if recommendations:
        message = f"Dear {user_name}, you can follow these recommendations for better sleep experience!\n\n"
        message += "\n".join([f"• {rec}" for rec in recommendations])
        message += "\n\nSmall adjustments can greatly improve your sleep quality!"
        return message
    
    return f"Dear {user_name}, focus on maintaining good sleep hygiene. Keep a consistent sleep schedule and create a relaxing bedtime routine for better sleep!"

@app.route('/personalized_prediction', methods=['POST'])
def personalized_prediction():
    """
    Endpoint for personalized sleep prediction with detailed analysis and recommendations.
    Follows the format requested in the UI design.
    """
    try:
        # Get data from request
        data = request.get_json()
        logger.info(f"Received personalized prediction request with data: {data}")
        
        # Initialize the sleep prediction service
        prediction_service = SleepPredictionService()
        
        # Generate the prediction and analysis
        response = prediction_service.analyze_sleep_data(data)

        # Send notification to Node.js backend via REST to broadcast through WebSocket
        try:
            backend_url = os.environ.get("BACKEND_BASE_URL", "http://20.2.139.176:3000")
            
            # Extract user ID from the request data if available
            user_id = data.get('userId') if isinstance(data, dict) else None
            
            notification_payload = {
                "title": "Sleep Prediction Update",
                "message": response.get("prediction", "New sleep prediction available"),
                "timestamp": datetime.datetime.utcnow().isoformat() + "Z",
            }
            
            # If user ID is available, send user-specific notification
            if user_id:
                notification_payload["userId"] = user_id
                notification_payload["targetType"] = "user"
            
            requests.post(
                f"{backend_url}/api/notifications",
                json=notification_payload,
                timeout=2,
            )
        except Exception as notify_err:
            logger.warning(f"Failed to notify backend: {notify_err}")
        
        logger.info(f"Returning personalized prediction response")
        return jsonify(response)
    
    except Exception as e:
        logger.error(f"Error in personalized_prediction endpoint: {str(e)}", exc_info=True)
        return jsonify({
            "error": str(e),
            "prediction": "😴 We couldn't analyze your sleep data properly.",
            "detailedAnalysis": "There was an error processing your data. Please check your inputs and try again.",
            "recommendations": "Please ensure all required fields are filled correctly."
        }), 500

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=True)
