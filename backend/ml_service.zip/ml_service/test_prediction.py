import json
from sleep_prediction_service import SleepPredictionService

def main():
    """Test the sleep prediction service with sample data"""
    # Sample input data matching the format from the requirements
    sample_data = {
        'Age': 35,
        'Gender': 'Female',
        'BMI_Category': 'Normal',
        'Sleep_Duration': 6.5,
        'Physical_Activity': 30,
        'Heart_Rate': 68,
        'Daily_Steps': 8000,
        'Stress_Level': 7,
        'Sleep_Quality': 6,
        'Awakenings': 2,
        'Electronic_Devices_Before_Bed': True,
        'Room_Temperature': 22,
        'Noise_Level': 'Low',
        'Caffeine_Intake': 1,
        'Alcohol_Consumption': 'Low',
        'Exercise_Frequency': '3-4',
        
        # Time-based features required for preprocessing
        'Bedtime_Hour': 23,
        'Bedtime_Minute': 30,
        'Wakeup_Hour': 6,
        'Wakeup_Minute': 0,
        'Weekend_Bedtime_Hour': 0,
        'Weekend_Bedtime_Minute': 30,
        'Weekend_Wakeup_Hour': 7,
        'Weekend_Wakeup_Minute': 0,
    }
    
    # Initialize the service
    prediction_service = SleepPredictionService()
    
    # Get prediction results
    results = prediction_service.analyze_sleep_data(sample_data)
    
    # Print results in a formatted way
    print("\n===== SLEEP PREDICTION RESULTS =====\n")
    print(f"Prediction: {results['prediction']}")
    
    print("\nDetailed Analysis:")
    # Format detailed analysis for better readability
    analysis = results['detailedAnalysis']
    print(analysis)

    print(f"\nSleep Disorder Probability: {results['sleepDisorderProbability']}")

    print("\nRecommendations:")
    recommendations = results['recommendations']
    for rec in recommendations:
        print(f"  - [Priority: {rec['priority']}] {rec['message']}")
    
    print(f"\nPrediction Score: {results['predictionScore']}/10")
    print(f"Normalized Score: {results['normalizedScore']}")
    print(f"Predicted Interruption Count: {results['predictedInterruptionCount']}")
    
    if results['predictedInterruptionWindows']:
        print("\nPredicted Interruption Windows:")
        for window in results['predictedInterruptionWindows']:
            print(f"  • {window['startTime']} - {window['endTime']} (Probability: {window['probability']})")

    
    # Save the results to a JSON file for reference
    with open('prediction_results.json', 'w') as f:
        json.dump(results, f, indent=2)
    print("\nResults saved to prediction_results.json")

if __name__ == "__main__":
    main()
