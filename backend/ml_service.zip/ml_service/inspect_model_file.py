import pickle

MODEL_FILE = 'improved_sleep_model.pkl'

with open(MODEL_FILE, 'rb') as f:
    obj = pickle.load(f)
    print("Type:", type(obj))
    print("Preview:", str(obj)[:500]) 