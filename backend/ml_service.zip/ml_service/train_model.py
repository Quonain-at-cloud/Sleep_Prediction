import pandas as pd
import numpy as np
import joblib
import matplotlib
matplotlib.use('Agg') # Set backend before pyplot import
import matplotlib.pyplot as plt
import os
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split, GridSearchCV

from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.metrics import (classification_report, accuracy_score, 
                            confusion_matrix, roc_auc_score, 
                            precision_recall_curve, f1_score)
from imblearn.over_sampling import SMOTE
from imblearn.pipeline import Pipeline as ImbPipeline
from xgboost import XGBClassifier
from sklearn.feature_selection import SelectFromModel

# Define paths
MODEL_PATH = os.path.join(os.path.dirname(__file__), 'sleep_model.pkl')
FEATURE_IMPORTANCE_PATH = os.path.join(os.path.dirname(__file__), 'feature_importance.png')

# Function to generate more realistic synthetic data
def get_dataset():
    """Generate synthetic sleep health data with realistic relationships"""
    np.random.seed(42)
    n_samples = 3000  # Increased sample size
    
    # Generate base features with realistic distributions
    age = np.random.normal(45, 15, n_samples).astype(int)
    age = np.clip(age, 18, 80)
    
    gender = np.random.choice(['Male', 'Female'], n_samples, p=[0.48, 0.52])
    
    bmi_categories = np.random.choice(
        ['Normal', 'Overweight', 'Obese', 'Underweight'], 
        n_samples, 
        p=[0.45, 0.35, 0.15, 0.05]
    )
    
    # Create realistic relationships between features
    stress_level = np.random.randint(1, 11, n_samples)
    physical_activity = np.clip(np.random.normal(45, 20, n_samples) - (age/4), 0, 120)
    heart_rate = np.clip(np.random.normal(72, 8, n_samples) + (stress_level * 0.8), 55, 100)
    daily_steps = np.clip(np.random.normal(7500, 2500, n_samples) + (physical_activity * 50), 1000, 20000)
    
    # Sleep duration based on age and stress
    base_sleep = 7.5 - (age * 0.01) - (stress_level * 0.1)
    sleep_duration = np.clip(np.random.normal(base_sleep, 1.2, n_samples), 3, 11)
    
    # Sleep patterns with realistic correlations
    weekday_bedtime = np.random.normal(22.5, 1.5, n_samples)  # Around 10:30 PM
    weekday_bedtime_hour = np.floor(weekday_bedtime).astype(int)
    weekday_bedtime_minute = ((weekday_bedtime % 1) * 60).astype(int)
    
    # Wake up time depends on bedtime and sleep duration
    weekday_wakeup = weekday_bedtime + (sleep_duration + np.random.normal(0, 0.5, n_samples))
    weekday_wakeup_hour = np.floor(weekday_wakeup % 24).astype(int)
    weekday_wakeup_minute = ((weekday_wakeup % 1) * 60).astype(int)
    
    # Weekend patterns differ from weekdays
    weekend_bedtime = weekday_bedtime + np.random.normal(1.5, 1, n_samples)  # Later bedtime
    weekend_bedtime_hour = np.floor(weekend_bedtime % 24).astype(int)
    weekend_bedtime_minute = ((weekend_bedtime % 1) * 60).astype(int)
    
    weekend_wakeup = weekend_bedtime + (sleep_duration + np.random.normal(1, 0.7, n_samples))  # Longer sleep
    weekend_wakeup_hour = np.floor(weekend_wakeup % 24).astype(int)
    weekend_wakeup_minute = ((weekend_wakeup % 1) * 60).astype(int)
    
    # Electronic device usage - more common in younger people
    device_usage_prob = 0.3 + (0.6 * (1 - (age / 80)))
    use_electronic_devices = np.random.binomial(1, device_usage_prob, n_samples).astype(bool)
    
    # Generate sleep disorder probabilities with realistic risk factors
    sleep_disorder_prob = (
        0.03 * (age - 40) +                   # Age factor
        0.1 * (heart_rate - 70) +              # Heart rate factor
        -0.4 * (sleep_duration - 7) +         # Sleep duration factor
        0.2 * (stress_level - 5) +            # Stress factor
        0.3 * (bmi_categories == 'Obese') +   # BMI factors
        0.15 * (bmi_categories == 'Overweight') +
        0.25 * use_electronic_devices +       # Electronic devices
        -0.0001 * daily_steps +              # Physical activity
        0.5 * (weekday_bedtime > 23.5)        # Late bedtime
    )
    
    # Normalize and convert to probabilities
    sleep_disorder_prob = 1 / (1 + np.exp(-sleep_disorder_prob))  # Sigmoid
    
    # Generate sleep disorders
    sleep_disorder = np.random.binomial(1, sleep_disorder_prob)
    sleep_disorder_type = np.where(
        sleep_disorder == 1,
        np.random.choice(
            ['Insomnia', 'Sleep Apnea', 'Restless Legs Syndrome'], 
            n_samples,
            p=[0.5, 0.3, 0.2]
        ),
        'None'
    )
    
    # Generate sleep quality score (1-10)
    base_quality = (
        7.0 - 
        0.4 * (stress_level / 10) - 
        0.3 * (sleep_disorder == 1) - 
        0.2 * (weekday_bedtime > 23.5) + 
        0.1 * (physical_activity / 100) +
        np.random.normal(0, 0.5, n_samples)
    )
    sleep_quality = np.clip(base_quality, 1, 10)
    
    # Create DataFrame
    data = pd.DataFrame({
        # Basic info
        'Age': age,
        'Gender': gender,
        'BMI_Category': bmi_categories,
        
        # Health metrics
        'Sleep_Duration': sleep_duration,
        'Physical_Activity': physical_activity,
        'Heart_Rate': heart_rate,
        'Daily_Steps': daily_steps,
        'Stress_Level': stress_level,
        'Sleep_Quality': sleep_quality,
        'Sleep_Disorder': sleep_disorder_type,
        
        # Sleep patterns
        'Bedtime_Hour': weekday_bedtime_hour,
        'Bedtime_Minute': weekday_bedtime_minute,
        'Wakeup_Hour': weekday_wakeup_hour,
        'Wakeup_Minute': weekday_wakeup_minute,
        'Weekend_Bedtime_Hour': weekend_bedtime_hour,
        'Weekend_Bedtime_Minute': weekend_bedtime_minute,
        'Weekend_Wakeup_Hour': weekend_wakeup_hour,
        'Weekend_Wakeup_Minute': weekend_wakeup_minute,
        'Awakenings': np.random.poisson(1.2, n_samples),
        'Electronic_Devices_Before_Bed': use_electronic_devices,
        
        # Environmental factors
        'Room_Temperature': np.clip(np.random.normal(21, 2, n_samples), 16, 28),
        'Noise_Level': np.random.choice(['Low', 'Medium', 'High'], n_samples, p=[0.6, 0.3, 0.1]),
        
        # Lifestyle factors
        'Caffeine_Intake': np.random.poisson(2, n_samples),
        'Alcohol_Consumption': np.random.choice(['None', 'Low', 'Moderate', 'High'], 
                                              n_samples, p=[0.5, 0.3, 0.15, 0.05]),
        'Exercise_Frequency': np.random.choice(['None', '1-2', '3-4', '5+'], 
                                            n_samples, p=[0.2, 0.4, 0.3, 0.1])
    })
    
    return data

def preprocess_data(df):
    """Preprocess data with enhanced feature engineering"""
    print("Preprocessing data with feature engineering...")
    
    # Create target variable
    df['Has_Sleep_Disorder'] = df['Sleep_Disorder'].apply(lambda x: 0 if x == 'None' else 1)
    
    # Feature engineering
    df['Sleep_Efficiency'] = df['Sleep_Duration'] / (
        (df['Wakeup_Hour'] + df['Wakeup_Minute']/60) - 
        (df['Bedtime_Hour'] + df['Bedtime_Minute']/60)
    )
    df['Social_Jetlag'] = abs(
        (df['Weekend_Bedtime_Hour'] + df['Weekend_Bedtime_Minute']/60) - 
        (df['Bedtime_Hour'] + df['Bedtime_Minute']/60)
    )
    df['Sleep_Regularity'] = 1 / (1 + df['Social_Jetlag'])
    df['Late_Night_Device_Use'] = df['Electronic_Devices_Before_Bed'] & (
        df['Bedtime_Hour'] >= 23)
    
    # Define feature sets
    numerical_features = [
        'Age', 'Sleep_Duration', 'Physical_Activity', 'Heart_Rate',
        'Daily_Steps', 'Stress_Level', 'Sleep_Quality', 'Awakenings',
        'Room_Temperature', 'Caffeine_Intake', 'Sleep_Efficiency',
        'Social_Jetlag', 'Sleep_Regularity'
    ]
    
    categorical_features = [
        'Gender', 'BMI_Category', 'Electronic_Devices_Before_Bed',
        'Late_Night_Device_Use', 'Noise_Level', 'Alcohol_Consumption',
        'Exercise_Frequency'
    ]
    
    # Preprocessing pipeline
    preprocessor = ColumnTransformer(
        transformers=[
            ('num', StandardScaler(), numerical_features),
            ('cat', OneHotEncoder(handle_unknown='ignore', sparse=False), categorical_features)
        ],
        remainder='drop'
    )
    
    # Split data
    X = df[numerical_features + categorical_features]
    y = df['Has_Sleep_Disorder']
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y)
    
    return X_train, X_test, y_train, y_test, preprocessor, numerical_features, categorical_features

def train_model(X_train, y_train, preprocessor):
    """Train model with hyperparameter tuning and class balancing"""
    print("Training model with hyperparameter tuning...")
    
    # Create pipeline with SMOTE and feature selection
    model = ImbPipeline([
        ('preprocessor', preprocessor),
        ('smote', SMOTE(random_state=42, sampling_strategy='minority')),
        ('feature_selection', SelectFromModel(
            RandomForestClassifier(n_estimators=100, random_state=42),
            threshold='median'
        )),
        ('classifier', XGBClassifier(
            random_state=42,
            eval_metric='logloss',
            use_label_encoder=False,
            scale_pos_weight=np.sum(y_train == 0) / np.sum(y_train == 1)
        ))
    ])
    
    # Define parameter grid for tuning
    param_grid = {
        'classifier__n_estimators': [100, 200],
        'classifier__max_depth': [3, 5, 7],
        'classifier__learning_rate': [0.01, 0.1],
        'classifier__subsample': [0.8, 1.0],
        'feature_selection__max_features': [10, 20, None]
    }
    
    # Perform grid search
    grid_search = GridSearchCV(
        model,
        param_grid,
        cv=5,
        scoring='f1',
        n_jobs=-1,
        verbose=1
    )
    
    grid_search.fit(X_train, y_train)
    
    print("\nBest parameters found:")
    print(grid_search.best_params_)
    
    return grid_search.best_estimator_

def evaluate_model(model, X_test, y_test):
    """Comprehensive model evaluation"""
    print("\nEvaluating model performance...")
    
    # Predictions
    y_pred = model.predict(X_test)
    y_proba = model.predict_proba(X_test)[:, 1]
    
    # Metrics
    accuracy = accuracy_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred)
    roc_auc = roc_auc_score(y_test, y_proba)
    
    print(f"Accuracy: {accuracy:.4f}")
    print(f"F1 Score: {f1:.4f}")
    print(f"ROC AUC: {roc_auc:.4f}")
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred))
    
    # Confusion matrix
    cm = confusion_matrix(y_test, y_pred)
    print("\nConfusion Matrix:")
    print(cm)
    
    # Feature importance
    try:
        feature_importances = model.named_steps['classifier'].feature_importances_
        selected_features = model.named_steps['feature_selection'].get_support()
        
        # Get feature names from preprocessor
        num_features = model.named_steps['preprocessor'].transformers_[0][2]
        cat_transformer = model.named_steps['preprocessor'].transformers_[1][1]
        cat_features = cat_transformer.get_feature_names(
            model.named_steps['preprocessor'].transformers_[1][2]
        )
        all_features = np.concatenate([num_features, cat_features])
        
        # Plot top 15 features
        top_n = 15
        indices = np.argsort(feature_importances)[-top_n:]
        plt.figure(figsize=(10, 8))
        plt.title('Top {} Feature Importances'.format(top_n))
        plt.barh(range(top_n), feature_importances[indices], align='center')
        plt.yticks(range(top_n), [all_features[i] for i in indices])
        plt.tight_layout()
        plt.savefig(FEATURE_IMPORTANCE_PATH)
        print(f"\nFeature importance plot saved to {FEATURE_IMPORTANCE_PATH}")
    except Exception as e:
        print(f"\nCould not generate feature importance plot: {str(e)}")
    
    # Precision-Recall curve
    precision, recall, _ = precision_recall_curve(y_test, y_proba)
    plt.figure()
    plt.plot(recall, precision, marker='.')
    plt.xlabel('Recall')
    plt.ylabel('Precision')
    plt.title('Precision-Recall Curve')
    # plt.show()
    
    return {'accuracy': accuracy, 'f1': f1, 'roc_auc': roc_auc}

def save_model(model, numerical_features, categorical_features):
    """Save model with metadata"""
    print(f"\nSaving model to {MODEL_PATH}...")
    
    model_info = {
        'model': model,
        'numerical_features': numerical_features,
        'categorical_features': categorical_features,
        'model_type': 'XGBoost',
        'version': '1.1'
    }
    
    joblib.dump(model_info, 'sleep_model.pkl')
    print(f"Model and metadata successfully saved to sleep_model.pkl")

def main():
    """Main training workflow"""
    print("=== Sleep Disorder Prediction Model Training ===")
    
    # Get data
    print("\nGenerating/loading dataset...")
    df = get_dataset()
    print(f"Dataset shape: {df.shape}")
    print(f"Class distribution:\n{df['Sleep_Disorder'].value_counts()}")
    
    # Preprocess
    X_train, X_test, y_train, y_test, preprocessor, num_feats, cat_feats = preprocess_data(df)
    
    # Train
    model = train_model(X_train, y_train, preprocessor)
    
    # Evaluate
    metrics = evaluate_model(model, X_test, y_test)
    
    # Save
    save_model(model, num_feats, cat_feats)
    
    print("\n=== Training Complete ===")
    print(f"Final Model Performance:")
    print(f"- Accuracy: {metrics['accuracy']:.4f}")
    print(f"- F1 Score: {metrics['f1']:.4f}")
    print(f"- ROC AUC: {metrics['roc_auc']:.4f}")

if __name__ == "__main__":
    main()