from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Dict, Any
import joblib
import os

# Load the model
MODEL_PATH = os.path.join(os.path.dirname(__file__), 'sleep_model.pkl')
model = joblib.load(MODEL_PATH)

app = FastAPI()

class PredictionRequest(BaseModel):
    sleepPatterns: Dict[str, Any]
    profileInfo: Dict[str, Any]
    dietaryHabits: Dict[str, Any]
    environmentalFactors: Dict[str, Any]

class PredictionResponse(BaseModel):
    prediction: float
    recommendations: List[str]

def preprocess_input(data: PredictionRequest) -> List[float]:
    # Convert input data to the format expected by the model
    # This function should map the input data to a list of numerical values
    # Example mapping, adjust according to your model's requirements
    return [
        data.profileInfo['age'],
        data.sleepPatterns['sleepDuration'],
        data.sleepPatterns['stressLevel'],
        data.environmentalFactors['lightIntensity'],
        data.environmentalFactors['temperature'],
        # Add other necessary fields
    ]

def generate_recommendations(input_data: List[float]) -> List[str]:
    # Generate recommendations based on the input data
    # This is a placeholder implementation
    recommendations = []
    if input_data[1] < 7:
        recommendations.append("Increase your sleep duration to at least 7 hours.")
    if input_data[2] > 3:
        recommendations.append("Consider stress-reducing activities before bed.")
    # Add more recommendation logic as needed
    return recommendations

@app.get("/health")
async def health_check():
    return {"status": "ok"}

@app.post("/predict", response_model=PredictionResponse)
async def predict(data: PredictionRequest):
    # Preprocess input data
    try:
        input_data = preprocess_input(data)
        prediction = model.predict([input_data])[0]
        recommendations = generate_recommendations(input_data)
        return PredictionResponse(prediction=prediction, recommendations=recommendations)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
