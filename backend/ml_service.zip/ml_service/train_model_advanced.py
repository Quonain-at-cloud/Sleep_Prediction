import pandas as pd
import numpy as np
import joblib
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split, RandomizedSearchCV, StratifiedKFold
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.metrics import (classification_report, accuracy_score, 
                            confusion_matrix, roc_auc_score, 
                            precision_recall_curve, f1_score)
from xgboost import XGBClassifier
from lightgbm import LGBMClassifier
import os

MODEL_PATH = os.path.join(os.path.dirname(__file__), 'advanced_sleep_model.pkl')

# --- Data loading and preprocessing (reuse from train_model_up.py) ---
def get_dataset():
    # ... copy from train_model_up.py ...
    np.random.seed(42)
    n_samples = 3000
    age = np.random.normal(45, 15, n_samples).astype(int)
    age = np.clip(age, 18, 80)
    gender = np.random.choice(['Male', 'Female'], n_samples, p=[0.48, 0.52])
    bmi_categories = np.random.choice(['Normal', 'Overweight', 'Obese', 'Underweight'], n_samples, p=[0.45, 0.35, 0.15, 0.05])
    stress_level = np.random.randint(1, 11, n_samples)
    physical_activity = np.clip(np.random.normal(45, 20, n_samples) - (age/4), 0, 120)
    heart_rate = np.clip(np.random.normal(72, 8, n_samples) + (stress_level * 0.8), 55, 100)
    daily_steps = np.clip(np.random.normal(7500, 2500, n_samples) + (physical_activity * 50), 1000, 20000)
    base_sleep = 7.5 - (age * 0.01) - (stress_level * 0.1)
    sleep_duration = np.clip(np.random.normal(base_sleep, 1.2, n_samples), 3, 11)
    weekday_bedtime = np.random.normal(22.5, 1.5, n_samples)
    weekday_bedtime_hour = np.floor(weekday_bedtime).astype(int)
    weekday_bedtime_minute = ((weekday_bedtime % 1) * 60).astype(int)
    weekday_wakeup = weekday_bedtime + (sleep_duration + np.random.normal(0, 0.5, n_samples))
    weekday_wakeup_hour = np.floor(weekday_wakeup % 24).astype(int)
    weekday_wakeup_minute = ((weekday_wakeup % 1) * 60).astype(int)
    weekend_bedtime = weekday_bedtime + np.random.normal(1.5, 1, n_samples)
    weekend_bedtime_hour = np.floor(weekend_bedtime % 24).astype(int)
    weekend_bedtime_minute = ((weekend_bedtime % 1) * 60).astype(int)
    weekend_wakeup = weekend_bedtime + (sleep_duration + np.random.normal(1, 0.7, n_samples))
    weekend_wakeup_hour = np.floor(weekend_wakeup % 24).astype(int)
    weekend_wakeup_minute = ((weekend_wakeup % 1) * 60).astype(int)
    device_usage_prob = 0.3 + (0.6 * (1 - (age / 80)))
    use_electronic_devices = np.random.binomial(1, device_usage_prob, n_samples).astype(bool)
    sleep_disorder_prob = (
        0.03 * (age - 40) + 0.1 * (heart_rate - 70) -0.4 * (sleep_duration - 7) +
        0.2 * (stress_level - 5) + 0.3 * (bmi_categories == 'Obese') +
        0.15 * (bmi_categories == 'Overweight') + 0.25 * use_electronic_devices -
        0.0001 * daily_steps + 0.5 * (weekday_bedtime > 23.5)
    )
    sleep_disorder_prob = 1 / (1 + np.exp(-sleep_disorder_prob))
    sleep_disorder = np.random.binomial(1, sleep_disorder_prob)
    sleep_disorder_type = np.where(
        sleep_disorder == 1,
        np.random.choice(['Insomnia', 'Sleep Apnea', 'Restless Legs Syndrome'], n_samples, p=[0.5, 0.3, 0.2]),
        'None'
    )
    base_quality = (
        7.0 - 0.4 * (stress_level / 10) - 0.3 * (sleep_disorder == 1) -
        0.2 * (weekday_bedtime > 23.5) + 0.1 * (physical_activity / 100) +
        np.random.normal(0, 0.5, n_samples)
    )
    sleep_quality = np.clip(base_quality, 1, 10)
    data = pd.DataFrame({
        'Age': age,
        'Gender': gender,
        'BMI_Category': bmi_categories,
        'Sleep_Duration': sleep_duration,
        'Physical_Activity': physical_activity,
        'Heart_Rate': heart_rate,
        'Daily_Steps': daily_steps,
        'Stress_Level': stress_level,
        'Sleep_Quality': sleep_quality,
        'Sleep_Disorder': sleep_disorder_type,
        'Bedtime_Hour': weekday_bedtime_hour,
        'Bedtime_Minute': weekday_bedtime_minute,
        'Wakeup_Hour': weekday_wakeup_hour,
        'Wakeup_Minute': weekday_wakeup_minute,
        'Weekend_Bedtime_Hour': weekend_bedtime_hour,
        'Weekend_Bedtime_Minute': weekend_bedtime_minute,
        'Weekend_Wakeup_Hour': weekend_wakeup_hour,
        'Weekend_Wakeup_Minute': weekend_wakeup_minute,
        'Awakenings': np.random.poisson(1.2, n_samples),
        'Electronic_Devices_Before_Bed': use_electronic_devices,
        'Room_Temperature': np.clip(np.random.normal(21, 2, n_samples), 16, 28),
        'Noise_Level': np.random.choice(['Low', 'Medium', 'High'], n_samples, p=[0.6, 0.3, 0.1]),
        'Caffeine_Intake': np.random.poisson(2, n_samples),
        'Alcohol_Consumption': np.random.choice(['None', 'Low', 'Moderate', 'High'], n_samples, p=[0.5, 0.3, 0.15, 0.05]),
        'Exercise_Frequency': np.random.choice(['None', '1-2', '3-4', '5+'], n_samples, p=[0.2, 0.4, 0.3, 0.1])
    })
    return data

def preprocess_data(df):
    # ... copy from train_model_up.py ...
    df['Has_Sleep_Disorder'] = df['Sleep_Disorder'].apply(lambda x: 0 if x == 'None' else 1)
    weekday_bedtime = df['Bedtime_Hour'] + df['Bedtime_Minute']/60
    weekend_bedtime = df['Weekend_Bedtime_Hour'] + df['Weekend_Bedtime_Minute']/60
    df['Sleep_Efficiency'] = df['Sleep_Duration'] / ((df['Wakeup_Hour'] + df['Wakeup_Minute']/60) - weekday_bedtime)
    df['Social_Jetlag'] = abs(weekend_bedtime - weekday_bedtime)
    df['Sleep_Regularity'] = 1 / (1 + df['Social_Jetlag'])
    df['Late_Night_Device_Use'] = df['Electronic_Devices_Before_Bed'] & (df['Bedtime_Hour'] >= 23)
    df['Sleep_Time_Variability'] = df.apply(lambda row: abs((row['Weekend_Bedtime_Hour'] - row['Bedtime_Hour']) + abs((row['Weekend_Wakeup_Hour'] - row['Wakeup_Hour']))/60), axis=1)
    df['Sleep_Deficit'] = np.where(df['Sleep_Duration'] < 7, 7 - df['Sleep_Duration'], 0)
    df['Stress_Sleep_Interaction'] = df['Stress_Level'] * (8 - df['Sleep_Duration'])
    df['Circadian_Disruption'] = abs(weekend_bedtime - weekday_bedtime)
    df['Stress_Sleep_Ratio'] = df['Stress_Level'] / (df['Sleep_Duration'] + 1e-6)
    df['BMI_Numeric'] = df['BMI_Category'].map({'Underweight': 0, 'Normal': 1, 'Overweight': 2, 'Obese': 3})
    df['Alcohol_Numeric'] = df['Alcohol_Consumption'].map({'None': 0, 'Low': 1, 'Moderate': 2, 'High': 3})
    df['Exercise_Numeric'] = df['Exercise_Frequency'].map({'None': 0, '1-2': 1, '3-4': 2, '5+': 3})

    numerical_features = [
        'Age', 'Sleep_Duration', 'Physical_Activity', 'Heart_Rate',
        'Daily_Steps', 'Stress_Level', 'Sleep_Quality', 'Awakenings',
        'Room_Temperature', 'Caffeine_Intake', 'Sleep_Efficiency',
        'Social_Jetlag', 'Sleep_Regularity', 'Sleep_Time_Variability',
        'Sleep_Deficit', 'Stress_Sleep_Interaction',
        'BMI_Numeric', 'Alcohol_Numeric', 'Exercise_Numeric',
        'Circadian_Disruption', 'Stress_Sleep_Ratio'
    ]

    categorical_features = [
        'Gender', 'BMI_Category', 'Electronic_Devices_Before_Bed',
        'Late_Night_Device_Use', 'Noise_Level', 'Alcohol_Consumption',
        'Exercise_Frequency'
    ]

    preprocessor = ColumnTransformer(
        transformers=[
            ('num', StandardScaler(), numerical_features),
            ('cat', OneHotEncoder(handle_unknown='ignore', sparse_output=False), categorical_features)
        ]
    )

    X = df[numerical_features + categorical_features]
    y = df['Has_Sleep_Disorder']
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
    return X_train, X_test, y_train, y_test, preprocessor, numerical_features, categorical_features

# --- Main advanced training script ---
def main():
    print("=== Advanced Sleep Disorder Model Training ===")
    df = get_dataset()
    X_train, X_test, y_train, y_test, preprocessor, num_feats, cat_feats = preprocess_data(df)

    # Define base models
    model_xgb = XGBClassifier(
        use_label_encoder=False, eval_metric='logloss', random_state=42, scale_pos_weight=3.0
    )
    model_lgbm = LGBMClassifier(random_state=42, class_weight='balanced')
    model_rf = RandomForestClassifier(random_state=42, class_weight='balanced')

    # Voting ensemble
    voting = VotingClassifier(
        estimators=[('xgb', model_xgb), ('lgbm', model_lgbm), ('rf', model_rf)],
        voting='soft',
        n_jobs=1
    )

    pipeline = Pipeline([
        ('preprocessor', preprocessor),
        ('classifier', voting)
    ])

    # Parameter grid for RandomizedSearchCV
    param_dist = {
        'classifier__xgb__n_estimators': [100, 200, 300, 400],
        'classifier__xgb__max_depth': [3, 4, 5, 6, 8],
        'classifier__xgb__learning_rate': [0.01, 0.05, 0.1, 0.2],
        'classifier__lgbm__n_estimators': [100, 200, 300, 400],
        'classifier__lgbm__max_depth': [3, 4, 5, 6, 8],
        'classifier__lgbm__learning_rate': [0.01, 0.05, 0.1, 0.2],
    }

    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    search = RandomizedSearchCV(
        pipeline,
        param_distributions=param_dist,
        n_iter=50,
        scoring='roc_auc',
        n_jobs=1,
        cv=cv,
        verbose=2,
        random_state=42
    )

    print("Starting RandomizedSearchCV...")
    search.fit(X_train, y_train)
    print("Best parameters:", search.best_params_)
    print("Best ROC AUC score:", search.best_score_)

    # Evaluate on test set
    best_model = search.best_estimator_
    X_test_processed = best_model.named_steps['preprocessor'].transform(X_test)
    y_pred = best_model.named_steps['classifier'].predict(X_test_processed)
    y_proba = best_model.named_steps['classifier'].predict_proba(X_test_processed)[:, 1]

    print("\nTest set evaluation:")
    print("Accuracy:", accuracy_score(y_test, y_pred))
    print("F1 Score:", f1_score(y_test, y_pred))
    print("ROC AUC:", roc_auc_score(y_test, y_proba))
    print("Classification Report:\n", classification_report(y_test, y_pred))

    # Save model
    joblib.dump({
        'model': best_model,
        'numerical_features': num_feats,
        'categorical_features': cat_feats
    }, MODEL_PATH)
    print("Advanced model saved as advanced_sleep_model.pkl")

    # Feature importance for XGBoost
    try:
        xgb_model = best_model.named_steps['classifier'].estimators_[0][1]
        feature_names = []
        feature_names.extend(best_model.named_steps['preprocessor'].named_transformers_['num'].get_feature_names_out())
        feature_names.extend(best_model.named_steps['preprocessor'].named_transformers_['cat'].get_feature_names_out())
        importances = xgb_model.feature_importances_
        indices = np.argsort(importances)[::-1]
        plt.figure(figsize=(12, 8))
        plt.title("Feature Importance (XGBoost, Advanced)")
        plt.bar(range(len(indices[:20])), importances[indices[:20]])
        plt.xticks(range(len(indices[:20])), [feature_names[i] for i in indices[:20]], rotation=45, ha='right')
        plt.tight_layout()
        plt.savefig("advanced_feature_importance_xgb.png", bbox_inches='tight', dpi=300)
        plt.close()
        print("Feature importance plot saved as advanced_feature_importance_xgb.png")
    except Exception as e:
        print("Feature importance plot failed:", e)

if __name__ == '__main__':
    main() 