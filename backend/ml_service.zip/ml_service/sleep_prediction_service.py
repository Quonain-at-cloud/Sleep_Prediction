import joblib
import numpy as np
import pandas as pd
from typing import Dict, Any, List, Tuple

class SleepPredictionService:
    def __init__(self):
        model_artifact = joblib.load('compatible_sleep_model.pkl')
        self.pipeline = model_artifact['pipeline']
        self.numerical_features = model_artifact['numerical_features']
        self.categorical_features = model_artifact['categorical_features']

    def _room_temp_status(self, temp):
        if temp is None:
            return "unknown"
        if 16 <= temp <= 26:
            return "normal"
        elif 26 < temp <= 32:
            return "slightly high"
        elif 32 < temp <= 40:
            return "high"
        elif temp > 40:
            return "very high"
        else:
            return "low"

    def _generate_recommendations(self, data: Dict[str, Any], user_name: str) -> List[Dict[str, Any]]:
        """Generate personalized recommendations based on input data and prediction results"""
        recommendations = []

        prediction, probability = self._predict_sleep_disorder(data)
        
        # Base recommendation
        recommendations.append({
            "priority": "high" if probability > 0.6 else "medium",
            "category": "general",
            "message": "Maintain a consistent sleep schedule, even on weekends.",
            "actionable": True
        })

        # Sleep Duration
        sleep_duration = self._calculate_sleep_duration(data)
        if sleep_duration < 6:
            recommendations.append({
                "priority": "high",
                "category": "sleep_duration",
                "message": f"Increase your sleep duration to at least 7 hours (currently {sleep_duration:.1f} hrs)",
                "actionable": True
            })
        elif sleep_duration > 9:
            recommendations.append({
                "priority": "medium",
                "category": "sleep_duration",
                "message": "Consider if excessive sleep duration might indicate an underlying issue.",
                "actionable": False
            })

        # If model predicts disorder
        if prediction == 1:
            disorder_type = self._predict_sleep_disorder_type(data)
            recommendations.append({
                "priority": "high",
                "category": "sleep_disorder",
                "message": f"Potential {disorder_type} detected. Probability: {probability:.0%}. Consult a sleep specialist.",
                "actionable": True
            })

        # Environmental factor
        if data.get('lightIntensity', 50) > 30:
            recommendations.append({
                "priority": "medium" if probability > 0.5 else "high",
                "category": "environment",
                "message": "Reduce bedroom light exposure for better melatonin production.",
                "actionable": True
            })

        # Stress Level
        if data.get('Stress_Level', 5) > 7:
            recommendations.append({
                "priority": "high",
                "category": "stress",
                "message": "Practice stress-reduction techniques before bedtime.",
                "actionable": True
            })

        # Room temperature recommendations
        room_temp = data.get('Room_Temperature', None)
        temp_status = self._room_temp_status(room_temp)
        if temp_status == "slightly high":
            recommendations.append({
                "priority": "medium",
                "category": "environment",
                "message": "Room temperature is slightly above the ideal range (16-26°C). Try to keep your room cooler for optimal sleep.",
                "actionable": True
            })
        elif temp_status == "high":
            recommendations.append({
                "priority": "high",
                "category": "environment",
                "message": "Room temperature is high (32-40°C). High temperatures can disturb sleep. Use a fan, AC, or ventilation to cool your room.",
                "actionable": True
            })
        elif temp_status == "very high":
            recommendations.append({
                "priority": "high",
                "category": "environment",
                "message": "Room temperature is very high (above 40°C). This is unsafe for sleep. Take immediate steps to cool your room.",
                "actionable": True
            })

        # Sort by priority
        priority_order = {"high": 0, "medium": 1, "low": 2}
        recommendations.sort(key=lambda x: priority_order[x["priority"]])

        return recommendations

    def _predict_sleep_disorder(self, data: Dict[str, Any]) -> Tuple[int, float]:
        """Return (prediction, probability) using the trained model"""
        import pandas as pd

        # Convert data to dataframe
        input_df = pd.DataFrame([data])

        # Preprocess the data (same as training)
        input_df = self._preprocess_input_data(input_df)

        # Predict using the pipeline
        prediction = self.pipeline.predict(input_df)[0]
        probability = self.pipeline.predict_proba(input_df)[0][1]

        return prediction, probability

    def _preprocess_input_data(self, df: pd.DataFrame) -> pd.DataFrame:
        """Preprocess input data with the same transformations as training"""
        # Feature engineering
        weekday_bedtime = df['Bedtime_Hour'] + df['Bedtime_Minute']/60
        weekend_bedtime = df['Weekend_Bedtime_Hour'] + df['Weekend_Bedtime_Minute']/60
        
        df['Sleep_Efficiency'] = df['Sleep_Duration'] / ((df['Wakeup_Hour'] + df['Wakeup_Minute']/60) - weekday_bedtime)
        df['Social_Jetlag'] = abs(weekend_bedtime - weekday_bedtime)
        df['Sleep_Regularity'] = 1 / (1 + df['Social_Jetlag'])
        df['Late_Night_Device_Use'] = df['Electronic_Devices_Before_Bed'] & (df['Bedtime_Hour'] >= 23)
        df['Sleep_Time_Variability'] = df.apply(lambda row: abs((row['Weekend_Bedtime_Hour'] - row['Bedtime_Hour']) + abs((row['Weekend_Wakeup_Hour'] - row['Wakeup_Hour']))/60), axis=1)
        df['Sleep_Deficit'] = np.where(df['Sleep_Duration'] < 7, 7 - df['Sleep_Duration'], 0)
        df['Stress_Sleep_Interaction'] = df['Stress_Level'] * (8 - df['Sleep_Duration'])
        df['Circadian_Disruption'] = abs(weekend_bedtime - weekday_bedtime)
        df['Stress_Sleep_Ratio'] = df['Stress_Level'] / (df['Sleep_Duration'] + 1e-6)
        
        # Encode categorical variables
        df['BMI_Numeric'] = df['BMI_Category'].map({'Underweight': 0, 'Normal': 1, 'Overweight': 2, 'Obese': 3})
        df['Alcohol_Numeric'] = df['Alcohol_Consumption'].map({'None': 0, 'Low': 1, 'Moderate': 2, 'High': 3})
        df['Exercise_Numeric'] = df['Exercise_Frequency'].map({'None': 0, '1-2': 1, '3-4': 2, '5+': 3})
        
        return df

    def _predict_sleep_disorder_type(self, data: Dict[str, Any]) -> str:
        """Use simple rule-based mapping based on known symptoms"""
        awakenings = data.get('awakeningsDuringNight', 0)
        sleep_duration = self._calculate_sleep_duration(data)

        if awakenings > 2 and sleep_duration < 6:
            return "insomnia"
        elif data.get('snoring', False):
            return "sleep apnea"
        elif data.get('restlessLegs', False):
            return "restless legs syndrome"
        else:
            return "unspecified sleep disorder"

    def _calculate_sleep_duration(self, data: Dict[str, Any]) -> float:
        return float(data.get('Sleep_Duration', 0))
    
    def analyze_sleep_data(self, data: Dict[str, Any]) -> Dict[str, Any]:

        prediction, probability = self._predict_sleep_disorder(data)
        sleep_duration = self._calculate_sleep_duration(data)
        prediction_score = self._calculate_prediction_score(data)
        disorder_prob = self._calculate_sleep_disorder_probability(data)
        normalized_score = round(prediction_score / 10, 2)
        recommendations = self._generate_recommendations(data, user_name=data.get("Name", "User"))
        room_temp = data.get('Room_Temperature', None)
        temp_status = self._room_temp_status(room_temp)
        temp_text = ""
        if temp_status == "normal":
            temp_text = f"Room temperature ({room_temp}°C) is within the ideal range (16-26°C) for optimal sleep."
        elif temp_status == "slightly high":
            temp_text = f"Room temperature ({room_temp}°C) is slightly above the ideal range (16-26°C). Consider cooling your room."
        elif temp_status == "high":
            temp_text = f"Room temperature ({room_temp}°C) is high (32-40°C). This can disturb sleep."
        elif temp_status == "very high":
            temp_text = f"Room temperature ({room_temp}°C) is very high (above 40°C). This is unsafe for sleep!"
        elif temp_status == "low":
            temp_text = f"Room temperature ({room_temp}°C) is below the ideal range (16-26°C). Consider warming your room."
        else:
            temp_text = "Room temperature data is not available."

        return {
            "prediction": "Disorder Detected" if prediction == 1 else "No Disorder Detected",
            "sleepDisorderProbability": round(probability, 3),
            "sleepDuration": sleep_duration,
            "predictionScore": prediction_score,
            "normalizedScore": normalized_score,
            "predictedInterruptionCount": 4 if disorder_prob > 0.7 else 1,
            "predictedInterruptionWindows": [
                {"startTime": "02:00 AM", "endTime": "02:30 AM", "probability": 0.6},
                {"startTime": "04:00 AM", "endTime": "04:15 AM", "probability": 0.5}
            ] if disorder_prob > 0.7 else [],
            "recommendations": recommendations,
            "detailedAnalysis": (
                f"User shows signs of {'a sleep disorder' if prediction else 'healthy sleep'}. "
                f"Stress level: {data.get('Stress_Level', 'N/A')}, "
                f"Sleep efficiency: {data.get('Sleep_Efficiency', 'N/A')}, "
                f"Duration: {sleep_duration} hrs. "
                f"Probability: {round(probability*100, 1)}%. "
                f"{temp_text}"
            )
        }

    def _calculate_prediction_score(self, data: Dict[str, Any]) -> float:
        """Heuristic scoring between 0-10"""
        score = 10
        if data.get('Stress_Level', 5) > 7:
            score -= 2
        if data.get('Sleep_Duration', 7) < 6:
            score -= 2
        if data.get('Sleep_Efficiency', 1) < 0.85:
            score -= 2
        return max(score, 0)

    def _calculate_sleep_disorder_probability(self, data: Dict[str, Any]) -> float:
        """Fake probability logic for now; can be replaced with real model-based one"""
        prob = 0.3
        if data.get('Stress_Level', 0) > 7:
            prob += 0.3
        if data.get('Sleep_Duration', 7) < 6:
            prob += 0.3
        return min(prob, 1.0)

    def _calculate_sleep_duration(self, data: Dict[str, Any]) -> float:
        return float(data.get("Sleep_Duration", 0))
