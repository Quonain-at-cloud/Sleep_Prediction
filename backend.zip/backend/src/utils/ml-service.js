const axios = require('axios');

// ML Service URL - Update this for production deployment
const ML_SERVICE_URL = process.env.ML_SERVICE_URL || 'http://20.2.139.176:5000';

// Function to check if ML service is available
async function checkMLServiceHealth() {
  try {
    const response = await axios.get(`${ML_SERVICE_URL}/health`, { timeout: 5000 });
    return response.status === 200;
  } catch (error) {
    console.error('ML service health check failed:', error.message);
    return false;
  }
}

// Function to get prediction from ML service
async function getPrediction(mlInputData) {
  try {
    const response = await axios.post(`${ML_SERVICE_URL}/predict`, mlInputData, {
      timeout: 30000,
      headers: {
        'Content-Type': 'application/json'
      }
    });
    return response.data;
  } catch (error) {
    console.error('Error getting prediction from ML service:', error.message);
    throw new Error(`ML service error: ${error.message}`);
  }
}

// Map sleep data to ML model input format for the Sleep Health Dataset model
function mapSleepDataToMLInput(sleepData, environmentalData, dietaryData) {
  // Map to the new model features based on Sleep Health Dataset
  const mappedData = {
    // Default values for Sleep Health Dataset features
    'Age': 35,  // Default age
    'Gender': 'Male',  // Default gender
    'BMI Category': 'Normal',  // Default BMI category
    'Sleep Duration': 7.0,  // Default sleep duration in hours
    'Physical Activity Level': 45,  // Default physical activity in minutes
    'Heart Rate': 70,  // Default heart rate in BPM
    'Daily Steps': 7000,  // Default daily steps
    'Stress Level': 5,  // Default stress level (1-10),
    // Environmental defaults
    'Light Intensity': 150, // lux
    'Temperature': 22, // °C
    'Sound Exposure': 'Quiet', // Qualitative category used by model
    
    // Keep backward compatibility with old features
    'caffeine_intake_mg': 0,
    'screen_time_minutes': 0
  };

  // Map sleep data if available
  if (sleepData) {
    // Map sleep duration from sleepData if available
    if (sleepData.sleepDuration) {
      mappedData['Sleep Duration'] = parseFloat(sleepData.sleepDuration);
    }
    
    // Map stress level (convert from 1-5 to 1-10 scale)
    if (sleepData.stressLevel) {
      mappedData['Stress Level'] = Math.min(10, sleepData.stressLevel * 2);
    }
    
    // Map demographic data if available
    if (sleepData.userProfile) {
      if (sleepData.userProfile.age) {
        mappedData['Age'] = parseInt(sleepData.userProfile.age);
      }
      
      if (sleepData.userProfile.gender) {
        mappedData['Gender'] = sleepData.userProfile.gender === 'male' ? 'Male' : 'Female';
      }
      
      if (sleepData.userProfile.bmi) {
        const bmi = parseFloat(sleepData.userProfile.bmi);
        if (bmi < 18.5) {
          mappedData['BMI Category'] = 'Underweight';
        } else if (bmi >= 18.5 && bmi < 25) {
          mappedData['BMI Category'] = 'Normal';
        } else if (bmi >= 25 && bmi < 30) {
          mappedData['BMI Category'] = 'Overweight';
        } else {
          mappedData['BMI Category'] = 'Obese';
        }
      }
    }
    
    // Map physical activity data
    if (sleepData.activities) {
      if (sleepData.activities.exerciseMinutes) {
        mappedData['Physical Activity Level'] = parseFloat(sleepData.activities.exerciseMinutes);
      }
      
      if (sleepData.activities.dailySteps) {
        mappedData['Daily Steps'] = parseInt(sleepData.activities.dailySteps);
      }
      
      // Map backward compatible fields
      if (sleepData.activities.caffeineIntake) {
        mappedData.caffeine_intake_mg = parseFloat(sleepData.activities.caffeineIntake);
      }
      
      if (sleepData.activities.screenTimeMinutes) {
        mappedData.screen_time_minutes = parseFloat(sleepData.activities.screenTimeMinutes);
      }
    }
  }

  // Map environmental data if available
  if (environmentalData) {
    // Persist raw environmental metrics so downstream model has explicit features
    if (environmentalData.lightIntensity !== undefined && environmentalData.lightIntensity !== null) {
      mappedData['Light Intensity'] = parseFloat(environmentalData.lightIntensity);
    }
    if (environmentalData.temperature !== undefined && environmentalData.temperature !== null) {
      mappedData['Temperature'] = parseFloat(environmentalData.temperature);
    }

    // Ambient temperature might influence heart rate slightly
    if (environmentalData.temperature) {
      const temp = parseFloat(environmentalData.temperature);
      // Adjust heart rate slightly based on temperature (higher temp, higher heart rate)
      const tempEffect = (temp - 22) * 0.5; // 0.5 BPM per degree C deviation from 22°C
      mappedData['Heart Rate'] = Math.max(60, Math.min(100, mappedData['Heart Rate'] + tempEffect));
    }
    
    // Light exposure can affect stress
    if (environmentalData.lightIntensity) {
      const lightIntensity = parseFloat(environmentalData.lightIntensity);
      // High light intensity might increase stress slightly
      if (lightIntensity > 300) {
        mappedData['Stress Level'] = Math.min(10, mappedData['Stress Level'] + 1);
      }
    }
    
    // Sound exposure / noise level can affect stress
    let soundExposureCategory = null;
    if (environmentalData.soundExposure) {
      soundExposureCategory = environmentalData.soundExposure;
    } else if (environmentalData.noiseLevel !== undefined && environmentalData.noiseLevel !== null) {
      const noiseVal = parseFloat(environmentalData.noiseLevel);
      if (noiseVal > 60) {
        soundExposureCategory = 'Loud';
      } else if (noiseVal > 30) {
        soundExposureCategory = 'Moderate';
      } else {
        soundExposureCategory = 'Quiet';
      }
    }

    if (soundExposureCategory) {
      // Map qualitative sound exposure so the ML model can use it
      mappedData['Sound Exposure'] = soundExposureCategory;
      if (soundExposureCategory.includes('Loud')) {
        mappedData['Stress Level'] = Math.min(10, mappedData['Stress Level'] + 2);
      } else if (soundExposureCategory.includes('Moderate')) {
        mappedData['Stress Level'] = Math.min(10, mappedData['Stress Level'] + 1);
      }
    }
  }

  // Map dietary data if available
  if (dietaryData) {
    // Meal regularity can affect sleep quality and stress levels
    let regularMeals = 0;
    if (dietaryData.isBreakfastRegular) regularMeals++;
    if (dietaryData.isLunchRegular) regularMeals++;
    if (dietaryData.isDinnerRegular) regularMeals++;
    
    // More regular meals generally means better sleep
    if (regularMeals < 2) {
      mappedData['Stress Level'] = Math.min(10, mappedData['Stress Level'] + 1);
    }
    
    // Analyze food types
    const allFoodTypes = [
      ...(dietaryData.selectedBreakfastFoodTypes || []),
      ...(dietaryData.selectedLunchFoodTypes || []),
      ...(dietaryData.selectedDinnerFoodTypes || [])
    ];
    
    // A balanced diet generally contributes to better sleep
    const isBalanced = allFoodTypes.includes('Proteins') && 
                      allFoodTypes.includes('Carbohydrates') && 
                      allFoodTypes.includes('Vegetables');
                      
    if (!isBalanced) {
      // Less balanced diet may increase stress slightly
      mappedData['Stress Level'] = Math.min(10, mappedData['Stress Level'] + 0.5);
    }
  }

  return mappedData;
}

module.exports = {
  checkMLServiceHealth,
  getPrediction,
  mapSleepDataToMLInput
};
